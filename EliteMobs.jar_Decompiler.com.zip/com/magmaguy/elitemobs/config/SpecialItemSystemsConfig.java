package com.magmaguy.elitemobs.config;

import com.magmaguy.elitemobs.items.customitems.CustomItem;
import com.magmaguy.elitemobs.magmacore.config.ConfigurationFile;
import com.magmaguy.elitemobs.magmacore.util.Logger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import lombok.Generated;
import org.bukkit.configuration.file.FileConfiguration;

public class SpecialItemSystemsConfig extends ConfigurationFile {
   private static final HashMap<CustomItem, Double> specialValues = new HashMap();
   private static final List<PendingSpecialItem> pendingSpecialItems = new ArrayList();
   private static boolean specialValuesResolved = false;
   private static boolean dropSpecialLoot;
   private static double bossChanceToDrop;
   private static double nonEliteChanceToDrop;
   private static double luckyTicketMultiplier;
   private static double criticalFailureChance;
   private static double challengeChance;
   private static double criticalFailureChanceDuringChallengeChance;
   private static String insufficientFundsMessage;
   private static String newFundsMessage;
   private static boolean announceImportantEnchantments;
   private static String successAnnouncement;
   private static String criticalFailureAnnouncement;
   private static String challengeAnnouncement;

   public SpecialItemSystemsConfig() {
      super("SpecialItemSystems.yml");
   }

   public static HashMap<CustomItem, Double> getSpecialValues() {
      if (!specialValuesResolved) {
         resolveSpecialItems();
      }

      return specialValues;
   }

   private static void resolveSpecialItems() {
      specialValuesResolved = true;

      for(PendingSpecialItem pending : pendingSpecialItems) {
         CustomItem customItem = CustomItem.getCustomItem(pending.filename + ".yml");
         if (customItem == null) {
            Logger.warn("Failed to get custom item " + pending.filename + ".yml for the special loot list!");
         } else {
            specialValues.put(customItem, pending.weight);
         }
      }

      pendingSpecialItems.clear();
   }

   private static void addDefaultEnchantmentBook(FileConfiguration fileConfiguration, String configFilename, double chance) {
      String key = "enchantedBookWeightedDropChance." + configFilename;
      fileConfiguration.addDefault(key, chance);
      pendingSpecialItems.add(new PendingSpecialItem(configFilename, fileConfiguration.getDouble(key)));
   }

   public void initializeValues() {
      specialValues.clear();
      pendingSpecialItems.clear();
      specialValuesResolved = false;
      dropSpecialLoot = ConfigurationEngine.setBoolean(List.of("Sets if special loot will drop."), this.fileConfiguration, "dropSpecialLoot", true);
      bossChanceToDrop = ConfigurationEngine.setDouble(List.of("Sets the chance of special loot dropping from any custom boss that can drop elite loot with a health multiplier over 1.0.", "This means all bosses, minibosses and marginally hard bosses."), this.fileConfiguration, "bossChanceToDrop", 0.1);
      nonEliteChanceToDrop = ConfigurationEngine.setDouble(List.of("Sets the chance of special loot dropping custom boss that can drop elite loot.", "Normal elites are excluded to avoid encouraging mob farms."), this.fileConfiguration, "normalChanceToDrop", 0.01);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_arrow_damage", (double)200.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_arrow_fire", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_arrow_infinite", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_arrow_knockback", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_channeling", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_critical_strikes", (double)1.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_damage_all", (double)200.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_damage_arthropods", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_damage_undead", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_depth_strider", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_dig_speed", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_drilling", (double)1.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_durability", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_earthquake", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_flamethrower", (double)0.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_frost_walker", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_hunter", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_ice_breaker", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_impaling", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_knockback", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_lightning", (double)0.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_loot_bonus_blocks", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_loot_bonus_mobs", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_loud_strikes", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_loyalty", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_luck", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_lure", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_mending", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_meteor_shower", (double)0.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_multishot", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_oxygen", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_piercing", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_plasma_boots", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_protection_environmental", (double)600.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_protection_explosions", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_protection_fall", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_protection_fire", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_protection_projectile", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_quick_charge", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_riptide", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_silk_touch", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_soul_speed", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_sweeping_edge", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_thorns", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "enchanted_book_water_worker", (double)10.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "elite_lucky_ticket", (double)100.0F);
      addDefaultEnchantmentBook(this.fileConfiguration, "elite_scrap_huge", (double)100.0F);
      this.fileConfiguration.setComments("enchantedBookWeightedDropChance", List.of("Sets the chance of a special item dropping over another special item.", "The higher the value, the higher the chance of that item getting picked over other items.", "Keep in mind that if values get too high, things with low values will become almost impossible to obtain."));
      luckyTicketMultiplier = ConfigurationEngine.setDouble(List.of("Multiplier for the lucky ticket success chance in enchantments. 2.0 = 2x"), this.fileConfiguration, "luckyTicketMultiplier", (double)2.0F);
      criticalFailureChance = ConfigurationEngine.setDouble(List.of("Chance of an item being lost if an item enchantment fails. This is a percentage of the base failure chance."), this.fileConfiguration, "criticalFailureChanceV2", 0.01);
      challengeChance = ConfigurationEngine.setDouble(List.of("Chance of a player being teleported to a challenge arena if an item enchantment fails. This is a percentage of the base failure chance.", "If the player defeats the arena, their item is upgraded correctly. If the lose, either it is not enchanted or, if they're unlucky, they may lose the item."), this.fileConfiguration, "challengeChance", 0.3);
      criticalFailureChanceDuringChallengeChance = ConfigurationEngine.setDouble(List.of("Chance of an item being lost if a player loses the enchantment challenge. This is a percentage of the base failure chance."), this.fileConfiguration, "criticalFailureChanceDuringChallengeChance", 0.1);
      insufficientFundsMessage = ConfigurationEngine.setString(List.of("Sets the message sent when players do not have enough elite coins to enchant an item"), this.file, this.fileConfiguration, "insufficientFundsMessage", "&8[EliteMobs] &c$price $currencyName is required to enchant $itemName, but you only have $currentAmount!", true);
      newFundsMessage = ConfigurationEngine.setString(List.of("Sets the message sent when players after deducting the funds"), this.file, this.fileConfiguration, "newFundsMessage", "&8[EliteMobs] &fYou just spent $price $currencyName! You now have $currentAmount $currencyName.", true);
      announceImportantEnchantments = ConfigurationEngine.setBoolean(List.of("Sets if enchantments of items with more than 10 enchantments in them will be announced"), this.fileConfiguration, "successAnnouncement", true);
      successAnnouncement = ConfigurationEngine.setString(List.of("Sets the message announced to all players when successfully enchanting an item with more than 10 enchantments"), this.file, this.fileConfiguration, "successAnnouncement", "&8[EliteMobs] $player &2has successfully enchanted $itemName&2!", true);
      challengeAnnouncement = ConfigurationEngine.setString(List.of("Sets the message announced to all players when they get a boss fight while trying to enchant an item with more than 10 enchantments"), this.file, this.fileConfiguration, "challengeAnnouncement", "&8[EliteMobs] $player &6is challenging a boss to enchant $itemName&6!", true);
      criticalFailureAnnouncement = ConfigurationEngine.setString(List.of("Sets the message announced to all players when losing an item while trying to enchant it if the item has more than 10 enchantments"), this.file, this.fileConfiguration, "criticalFailureAnnouncement", "&8[EliteMobs] $player &clost $itemName &cwhile trying to enchant it!", true);
   }

   @Generated
   public static boolean isDropSpecialLoot() {
      return dropSpecialLoot;
   }

   @Generated
   public static double getBossChanceToDrop() {
      return bossChanceToDrop;
   }

   @Generated
   public static double getNonEliteChanceToDrop() {
      return nonEliteChanceToDrop;
   }

   @Generated
   public static double getLuckyTicketMultiplier() {
      return luckyTicketMultiplier;
   }

   @Generated
   public static double getCriticalFailureChance() {
      return criticalFailureChance;
   }

   @Generated
   public static double getChallengeChance() {
      return challengeChance;
   }

   @Generated
   public static double getCriticalFailureChanceDuringChallengeChance() {
      return criticalFailureChanceDuringChallengeChance;
   }

   @Generated
   public static String getInsufficientFundsMessage() {
      return insufficientFundsMessage;
   }

   @Generated
   public static String getNewFundsMessage() {
      return newFundsMessage;
   }

   @Generated
   public static boolean isAnnounceImportantEnchantments() {
      return announceImportantEnchantments;
   }

   @Generated
   public static String getSuccessAnnouncement() {
      return successAnnouncement;
   }

   @Generated
   public static String getCriticalFailureAnnouncement() {
      return criticalFailureAnnouncement;
   }

   @Generated
   public static String getChallengeAnnouncement() {
      return challengeAnnouncement;
   }

   private static record PendingSpecialItem(String filename, double weight) {
   }
}
