package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class NorthPoleMinidungeon extends ContentPackagesConfigFields {
   public NorthPoleMinidungeon() {
      super("north_pole_minidungeon", true, "&2[Dynamic] &9The North Pole", new ArrayList(List.of("&fThe Christmas minidungeon!", "&6Credits: MagmaGuy & 69OzCanOfBepis")), "https://nightbreak.io/plugin/elitemobs/#north-pole", ContentPackagesConfigFields.DungeonSizeCategory.MINIDUNGEON, "em_north_pole", Environment.NORMAL, true, "em_north_pole,-258.5,41.2,-514.5,47,0", "em_north_pole,-264.5,43.2,-503.5,47,0", 0, "Difficulty: &6Medium\n$bossCount bosses, from level $lowestTier to $highestTier\n&6Christmas in a snow globe!", "&8[EM] &7You have reached the North Pole! &fHave you been naughty this year?", "&8[EM] &7Come back and visit. &fThere are plenty of sweets and treats for next time!", List.of("filename=northpole_santa_claus.yml"), "the_north_pole", -1, false);
      this.contentType = ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON;
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setSetupMenuDescription(List.of("&2A dynamic Christmas-themed Minidungeon!"));
      this.setNightbreakSlug("north-pole");
   }
}
