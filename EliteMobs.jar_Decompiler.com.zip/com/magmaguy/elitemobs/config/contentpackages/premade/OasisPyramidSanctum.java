package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class OasisPyramidSanctum extends ContentPackagesConfigFields {
   public OasisPyramidSanctum() {
      super("oasis_pyramid_sanctum", true, "&2[lvl 055] &6The Oasis Pyramid", new ArrayList(List.of("&fThe final dungeon of the Oasis adventure!", "&6Credits: 69OzCanOfBepis, Frostcone, MagmaGuy")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.SANCTUM, "em_id_oasis_pyramid", Environment.NORMAL, true, "em_id_oasis_pyramid,-9.5,77.0,-153.5,-115,17", "em_id_oasis_pyramid,0.5,75.0,-169.5,-180,3", 0, "&aSanctum &7- Level 55\n$bossCount boss encounters\n&6The final dungeon of the\n&6Oasis adventure!", "&bWelcome to the Pyramid!", "&bYou have left the Pyramid!", List.of("filename=oasis_pharaoh_p1.yml"), "em_id_oasis_pyramid", 55, false);
      this.setDifficulties(List.of(Map.of("name", "normal", "id", 0)));
      this.setListedInTeleports(false);
      this.setNightbreakSlug("the-oasis-adventure");
   }
}
