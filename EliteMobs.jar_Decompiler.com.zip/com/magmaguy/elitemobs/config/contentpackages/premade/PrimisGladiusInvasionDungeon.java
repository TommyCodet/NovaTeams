package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class PrimisGladiusInvasionDungeon extends ContentPackagesConfigFields {
   public PrimisGladiusInvasionDungeon() {
      super("primis_gladius_invasion_dungeon", true, "&2[lvl 000-020] &aPrimis - Gladius Invasion", new ArrayList(List.of("&fIt is time to take Gladius back!", "&6Credits: 69OzCanOfBepis, Frostcone, MagmaGuy")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.DUNGEON, "em_id_primis_gladius", Environment.NETHER, true, "em_id_primis_gladius,-108.5,69.0,40.5,-90.499999,0", "em_id_primis_gladius,-100.5,69.0,40.5,-69.499999,0", 0, "&aDungeon &7- Levels 1-20\n$bossCount boss encounters\n&aIt is time to take\n&aGladius back!", "&bWelcome to the Gladius Invasion!", "2&bYou have left the Gladius Invasion!", List.of("filename=primis_gladius_bell_id.yml"), "em_id_primis_gladius", 1, false);
      this.setDifficulties(List.of(Map.of("name", "normal", "id", 0, "levelSync", 18), Map.of("name", "hard", "id", 1, "levelSync", 15), Map.of("name", "mythic", "id", 2, "levelSync", 12)));
      this.setMaxPlayerCount(5);
      this.setListedInTeleports(false);
      this.setNightbreakSlug("primis-adventure");
   }
}
