package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class SteamworksLair extends ContentPackagesConfigFields {
   public SteamworksLair() {
      super("steamworks_lair", true, "&2[Dynamic] &6The Steamworks", List.of("&fA steampunk inspired lair!"), "https://nightbreak.io/plugin/elitemobs/#the-steamworks", ContentPackagesConfigFields.DungeonSizeCategory.LAIR, "em_steamworks_lair", Environment.NORMAL, true, "em_steamworks_lair,-46.5,-48.8,-104.5,42,0", "em_steamworks_lair,-50.5,-48.8,-99.5,40,0", 1, "&aDynamic Lair\n$bossCount boss encounters\n&6A steampunk inspired lair\n&6with mechanical challenges!", "&6Reach the top and mind your step!", "&6Now leaving the clockwork dominion!", List.of("filename=the_steamworks_clk_wrx702_p1.yml"), "the_steamworks", -1, false);
      this.contentType = ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON;
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setSetupMenuDescription(List.of("&2A Dynamic Lair where you choose the level!"));
      this.setNightbreakSlug("the-steamworks");
   }
}
