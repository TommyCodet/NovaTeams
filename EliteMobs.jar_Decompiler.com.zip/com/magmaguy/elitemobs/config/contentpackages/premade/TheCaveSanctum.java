package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheCaveSanctum extends ContentPackagesConfigFields {
   public TheCaveSanctum() {
      super("the_cave_sanctum", true, "&2[Dynamic] &3The Cave Sanctum", new ArrayList(List.of("&fThe perfect starter instanced sanctum!", "&6Credits: MagmaGuy, Frostcone, 69OzCanOfBepis, Realm of Lotheridon")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.SANCTUM, "em_id_the_cave", Environment.NORMAL, true, "em_id_the_cave,0.5,65,0.5,70,0", "em_id_the_cave,-18.5,58,-17.5,90.0,30.0", 0, "&aDynamic Sanctum\n$bossCount boss encounters\n&7Explore the depths of\n&7the cave!", "&bYou've been asked to clear the path to the underground. Deal with the thing in the cave!", "&bYou have left The Cave!", List.of("filename=the_cave_boiler_p1.yml"), "em_id_the_cave", -1, false);
      this.setContentType(ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON);
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setNightbreakSlug("story-mode-dungeons");
   }
}
