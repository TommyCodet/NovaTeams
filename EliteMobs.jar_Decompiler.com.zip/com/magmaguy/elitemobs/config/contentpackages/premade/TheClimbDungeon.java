package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheClimbDungeon extends ContentPackagesConfigFields {
   public TheClimbDungeon() {
      super("the_climb_dungeon", true, "&2[Dynamic] &3The Climb Dungeon", new ArrayList(List.of("&fThe perfect starter instanced dungeon!", "&6Credits: MagmaGuy, Frostcone, 69OzCanOfBepis, Realm of Lotheridon")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.DUNGEON, "em_id_the_climb", Environment.NORMAL, true, "em_id_the_climb,371.5,34,350.5,-70.0,-10.0", "em_id_the_climb,379.5,36,352.5,-70,-10", 0, "&aDynamic Dungeon\n$bossCount boss encounters\n&3Scale the heights of\n&3this dangerous ascent!", "&bYou've been asked to investigate the path to the caves. Climb your way to the top!", "&bYou have left The Climb!", List.of("filename=the_climb_undead_beastmaster.yml", "filename=the_climb_skeletal_shadow.yml", "filename=the_climb_bone_champion.yml", "filename=the_climb_undead_guardian.yml"), "em_id_the_climb", -1, false);
      this.setContentType(ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON);
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setNightbreakSlug("story-mode-dungeons");
   }
}
