package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheColosseum extends ContentPackagesConfigFields {
   public TheColosseum() {
      super("the_colosseum_lair", true, "&2[Dynamic] &8The Colosseum", List.of("&fA colosseum!", "&6Credits: MagmaGuy, Dali, Frost"), "https://nightbreak.io/plugin/elitemobs/#the-colosseum", ContentPackagesConfigFields.DungeonSizeCategory.LAIR, "em_the_colosseum", Environment.NORMAL, true, "em_the_colosseum,-83.5,66.0,251.5,-72,0", "em_the_colosseum,-79.5,65.2,253.5,-66,0", 0, "Difficulty: &cHard\n$bossCount bosses, from tier $lowestTier to $highestTier\n&2A great Lair!", "&8[EM] &8Now entering the Colosseum. Do you dare challenge the champion...", "&8[EM] &8You have left the Colosseum.", List.of("filename=colosseum_tier_70_boss_p1.yml"), "the_colosseum", -1, false);
      this.contentType = ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON;
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setSetupMenuDescription(List.of("&2A dynamic Lair!"));
      this.setNightbreakSlug("the-colosseum-remake-soon");
   }
}
