package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheDeepMinesDungeon extends ContentPackagesConfigFields {
   public TheDeepMinesDungeon() {
      super("the_deep_mines_dungeon", true, "&2[Dynamic] &3The Deep Mines Dungeon", new ArrayList(List.of("&fBelow lies the deepest mine ever dug.", "&6Credits: Dali, MagmaGuy, FrostCone")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.SANCTUM, "em_id_the_deep_mines", Environment.NORMAL, true, "em_id_the_deep_mines,-205.5,154,-85.5,0,0", "em_id_the_deep_mines,-207.5,154,-68.5,0,0", 0, "&aDynamic Sanctum\n$bossCount boss encounters\n&8Below lies the deepest\n&8mine ever dug.", "&bVenture far down and find out how deep the deep mines are.", "&bYou have left The Deep Mines!", List.of("filename=em_id_the_deep_mines_tnt_box.yml", "filename=em_id_the_deep_mines_boss_the_pursuer_p1.yml"), "em_id_the_deep_mines", -1, false);
      this.setContentType(ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON);
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setNightbreakSlug("story-mode-dungeons");
   }
}
