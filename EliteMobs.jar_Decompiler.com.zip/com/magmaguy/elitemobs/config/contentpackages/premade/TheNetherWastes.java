package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheNetherWastes extends ContentPackagesConfigFields {
   public TheNetherWastes() {
      super("the_nether_wastes_dungeon", true, "&2[Dynamic] &3The Nether Wastes Dungeon", new ArrayList(List.of("&fAn unexplored part of the Nether.", "&6Credits: MagmaGuy, Frostcone, Dali_")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.DUNGEON, "em_id_the_nether_wastes", Environment.NORMAL, true, "em_id_the_nether_wastes,38.5,84,64.5,-155,0", "em_id_the_nether_wastes,41.5,82.5,55.5,-167,0", 0, "&aDynamic Dungeon\n$bossCount boss encounters\n&cAn unexplored and dangerous\n&cpart of the Nether.", "&bTraverse the wastes and see what you can find.", "&bYou have left The Nether Wastes!", List.of("filename=em_id_the_nether_wastes_miniboss_5_shroud_p1.yml"), "em_id_the_nether_wastes", -1, false);
      this.setContentType(ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON);
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setNightbreakSlug("story-mode-dungeons");
   }
}
