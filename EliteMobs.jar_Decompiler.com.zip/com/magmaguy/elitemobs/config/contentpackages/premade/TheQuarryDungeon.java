package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class TheQuarryDungeon extends ContentPackagesConfigFields {
   public TheQuarryDungeon() {
      super("the_quarry_dungeon", true, "&2[Dynamic] &3The Quarry Dungeon", new ArrayList(List.of("&fAn ancient dwarven quarry deep underground.", "&6Credits: Dali_, MagmaGuy, Frostcone")), "https://discord.gg/eSxvPbWYy4", ContentPackagesConfigFields.DungeonSizeCategory.DUNGEON, "em_id_the_quarry", Environment.NORMAL, true, "em_id_the_quarry,230.5,144,102.5,-67,0", "em_id_the_quarry,245.5,138,109.5,-90,30", 0, "&aDynamic Dungeon\n$bossCount boss encounters\n&3An ancient dwarven quarry\n&3deep underground.", "&bGo down into the quarry and get that lift working.", "&bYou have left The Quarry!", List.of("filename=em_id_the_quarry_quarry_smith.yml", "filename=em_id_the_quarry_royal_wizard_three.yml", "filename=LiftStateFinishDungeon.yml"), "em_id_the_quarry", -1, false);
      this.setContentType(ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON);
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setNightbreakSlug("story-mode-dungeons");
   }
}
