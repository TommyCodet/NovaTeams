package com.magmaguy.elitemobs.config.contentpackages.premade;

import com.magmaguy.elitemobs.config.contentpackages.ContentPackagesConfigFields;
import java.util.List;
import java.util.Map;
import org.bukkit.World.Environment;

public class VampireManorDungeon extends ContentPackagesConfigFields {
   public VampireManorDungeon() {
      super("vampire_manor_lair", true, "&2[Dynamic] &4The Vampire Manor", List.of("&6Defeat the Vampire King!"), "https://nightbreak.io/plugin/elitemobs/#the-vampire-manor", ContentPackagesConfigFields.DungeonSizeCategory.LAIR, "em_the_vampire_manor", Environment.NETHER, true, "em_the_vampire_manor,283.5,31.0,1591.5,-180,0", "em_the_vampire_manor,281.5,31.0,1587.5,-180,0", 1, "&aDynamic Lair\n$bossCount boss encounters\n&4Enter the manor and\n&4defeat the Vampire King!", "&8[EM] &4You have entered the Vampire Manor!", "&8[EM] &4You have left the Vampire Manor!", List.of("filename=vampire_king_final_boss.yml"), "vampire_manor", -1, false);
      this.contentType = ContentPackagesConfigFields.ContentType.DYNAMIC_DUNGEON;
      this.setDifficulties(List.of(Map.of("name", "normal", "levelSync", "+5", "id", 0), Map.of("name", "hard", "levelSync", "+0", "id", 1), Map.of("name", "mythic", "levelSync", "-5", "id", 2)));
      this.setSetupMenuDescription(List.of("&2A Dynamic Lair where you choose the level!"));
      this.setNightbreakSlug("the-vampire-manor");
   }
}
