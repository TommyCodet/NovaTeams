package com.magmaguy.elitemobs.config.menus.premade;

import com.magmaguy.elitemobs.MetadataHandler;
import com.magmaguy.elitemobs.config.ConfigurationEngine;
import com.magmaguy.elitemobs.config.CustomModelsConfig;
import com.magmaguy.elitemobs.config.menus.MenusConfigFields;
import com.magmaguy.elitemobs.magmacore.util.ItemStackGenerator;
import com.magmaguy.elitemobs.utils.CustomModelAdder;
import com.magmaguy.elitemobs.utils.ItemStackSerializer;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class BuyOrSellMenuConfig extends MenusConfigFields {
   public static String SHOP_NAME;
   public static ItemStack INFORMATION_ITEM;
   public static int INFORMATION_SLOT;
   public static ItemStack BUY_PROCEDURAL_ITEM;
   public static ItemStack BUY_CUSTOM_ITEM;
   public static int BUY_SLOT;
   public static ItemStack SELL_ITEM;
   public static int SELL_SLOT;

   public BuyOrSellMenuConfig() {
      super("buy_or_sell_menu", true);
   }

   public void processAdditionalFields() {
      SHOP_NAME = ConfigurationEngine.setString(this.file, this.fileConfiguration, "shopName", "[EM] Buy or Sell", true);
      ItemStackSerializer.serialize("informationButton", ItemStackGenerator.generateSkullItemStack("magmaguy", "&4&lEliteMobs &r&cby &4&lMagmaGuy", new ArrayList(List.of("&8Support the plugins you enjoy!", "&aClick on the emerald to buy items!", "&cClick on the redstone to sell items!"))), this.fileConfiguration);
      INFORMATION_ITEM = ItemStackSerializer.deserialize("informationButton", this.fileConfiguration, this.file);
      INFORMATION_SLOT = ConfigurationEngine.setInt(this.fileConfiguration, "informationButtonSlot", 4);
      ItemStackSerializer.serialize("buyProcedurallyGeneratedItems", ItemStackGenerator.generateItemStack(Material.EMERALD, "Buy items", new ArrayList(), MetadataHandler.signatureID), this.fileConfiguration);
      BUY_PROCEDURAL_ITEM = ItemStackSerializer.deserialize("buyProcedurallyGeneratedItems", this.fileConfiguration, this.file);
      ItemStackSerializer.serialize("buyCustomItems", ItemStackGenerator.generateItemStack(Material.EMERALD, "Buy custom items", new ArrayList(), MetadataHandler.signatureID), this.fileConfiguration);
      CustomModelAdder.addCustomModel(BUY_PROCEDURAL_ITEM, CustomModelsConfig.bagOfCoins);
      BUY_CUSTOM_ITEM = ItemStackSerializer.deserialize("buyCustomItems", this.fileConfiguration, this.file);
      ItemStackSerializer.serialize("sellItems", ItemStackGenerator.generateItemStack(Material.REDSTONE, "Sell items", new ArrayList(), MetadataHandler.signatureID), this.fileConfiguration);
      CustomModelAdder.addCustomModel(BUY_CUSTOM_ITEM, CustomModelsConfig.bagOfCoins);
      SELL_ITEM = ItemStackSerializer.deserialize("sellItems", this.fileConfiguration, this.file);
      CustomModelAdder.addCustomModel(SELL_ITEM, CustomModelsConfig.handWithCoins);
      BUY_SLOT = ConfigurationEngine.setInt(this.fileConfiguration, "buySlot", 11);
      SELL_SLOT = ConfigurationEngine.setInt(this.fileConfiguration, "sellSlot", 15);
   }
}
