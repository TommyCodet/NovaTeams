package com.magmaguy.elitemobs.config.menus.premade;

import com.magmaguy.elitemobs.config.AdventurersGuildConfig;
import com.magmaguy.elitemobs.config.ConfigurationEngine;
import com.magmaguy.elitemobs.config.menus.MenusConfigFields;
import com.magmaguy.elitemobs.magmacore.util.ItemStackGenerator;
import com.magmaguy.elitemobs.playerdata.statusscreen.PlayerStatusScreen;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;

public class PlayerStatusMenuConfig extends MenusConfigFields {
   private static final String[] indexTextLines = new String[13];
   private static final String[] indexHoverLines = new String[13];
   private static final String[] indexCommandLines = new String[13];
   private static final String[] statsTextLines = new String[13];
   private static final String[] statsHoverLines = new String[13];
   private static final String[] statsCommandLines = new String[13];
   private static final String[] gearTextLines = new String[13];
   private static final String[] gearHoverLines = new String[13];
   private static final String[] teleportTextLines = new String[13];
   private static final String[] teleportHoverLines = new String[13];
   private static final String[] teleportCommandLines = new String[13];
   private static final String[] commandsTextLines = new String[13];
   private static final String[] commandsHoverLines = new String[13];
   private static final String[] commandsCommandLines = new String[13];
   private static final String[] bossTrackerTextLines = new String[13];
   private static final String[] bossTrackerHoverLines = new String[13];
   private static final String[] bossTrackerCommandLines = new String[13];
   private static boolean doStatsPage;
   private static boolean doGearPage;
   private static boolean doTeleportsPage;
   private static boolean doCommandsPage;
   private static boolean doQuestTrackingPage;
   private static boolean doBossTrackingPage;
   private static String teleportChestMenuName;
   private static String bossTrackerChestMenuName;
   private static String onBossTrackHover;
   private static String onTeleportHover;
   private static String indexChestMenuName;
   private static ItemStack backItem;
   private static ItemStack indexHeaderItem;
   private static int indexHeaderSlot;
   private static ItemStack indexStatsItem;
   private static int indexStatsSlot;
   private static ItemStack indexGearItem;
   private static int indexGearSlot;
   private static ItemStack indexTeleportsItem;
   private static int indexTeleportsSlot;
   private static ItemStack indexCommandsItem;
   private static int indexCommandsSlot;
   private static ItemStack indexQuestTrackingItem;
   private static int indexQuestTrackingSlot;
   private static ItemStack indexBossTrackingItem;
   private static int indexBossTrackingSlot;
   private static String gearChestMenuName;
   private static ItemStack gearDamageItem;
   private static int gearDamageSlot;
   private static ItemStack gearArmorItem;
   private static int gearArmorSlot;
   private static ItemStack gearThreatItem;
   private static int gearThreatSlot;
   private static String statsChestMenuName;
   private static ItemStack statsMoneyItem;
   private static int statsMoneySlot;
   private static ItemStack statsGuildTierItem;
   private static int statsGuildTierSlot;
   private static ItemStack statsEliteKillsItem;
   private static int statsEliteKillsSlot;
   private static ItemStack statsMaxEliteLevelKilledItem;
   private static int statsMaxEliteLevelKilledSlot;
   private static ItemStack statsEliteDeathsItem;
   private static int statsEliteDeathsSlot;
   private static ItemStack statsQuestsCompletedItem;
   private static int statsQuestsCompletedSlot;
   private static ItemStack statsScoreItem;
   private static int statsScoreSlot;
   private static String commandsChestMenuName;
   private static ItemStack commandsAGItem;
   private static int commandsAGSlot;
   private static ItemStack commandsShareItemItem;
   private static int commandsShareItemSlot;
   private static String skillsItemDisplayName;
   private static String skillsItemLore1;
   private static String skillsItemLore2;
   private static String skillsItemClickLore;
   private static String skillsPageHeader;
   private static String skillsPageLevelFormat;
   private static String skillsPageXpFormat;
   private static String skillItemDisplayNameFormat;
   private static String skillItemSelectLore1;
   private static String skillItemSelectLore2;
   private static String dialogTitlePlayerStatus;
   private static String dialogTitleStats;
   private static String dialogTitleGear;
   private static String dialogTitleTeleports;
   private static String dialogTitleCommands;
   private static String dialogTitleQuests;
   private static String dialogTitleBossTracking;
   private static String dialogTitleSkills;
   private static String dialogNoActiveQuests;
   private static String dialogActiveQuestsFormat;
   private static String dialogBackButton;

   public PlayerStatusMenuConfig() {
      super("player_status_screen", true);
   }

   private static void indexLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      indexTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "indexTexts" + line, text, true);
      indexHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "indexHovers" + line, hover, true);
      indexCommandLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "indexCommands" + line, command, false);
   }

   private static void statsLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      statsTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "statsText" + line, text, true);
      statsHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "statsHover" + line, hover, true);
      statsCommandLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "statsCommand" + line, command, false);
   }

   private static void gearLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      gearTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "gearText" + line, text, true);
      gearHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "gearHover" + line, hover, true);
   }

   private static void teleportLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      teleportTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "teleportTextV2" + line, text, true);
      teleportHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "teleportHoverV2" + line, hover, true);
      teleportCommandLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "teleportCommandV2" + line, command, false);
   }

   private static void commandsLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      commandsTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "commandsText" + line, text, true);
      commandsHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "commandsHover" + line, hover, true);
      commandsCommandLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "commandsCommand" + line, command, false);
   }

   private static void bossTrackerLineCreator(int line, String text, String hover, String command, FileConfiguration fileConfiguration, File file) {
      bossTrackerTextLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "bossTrackerText" + line, text, true);
      bossTrackerHoverLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "bossTrackerHover" + line, hover, true);
      bossTrackerCommandLines[line] = ConfigurationEngine.setString(file, fileConfiguration, "bossTrackerCommand" + line, command, false);
   }

   public void processAdditionalFields() {
      doStatsPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doStatsPage", true);
      doGearPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doGearPage", true);
      doTeleportsPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doTeleportsPage", true);
      doCommandsPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doCommandsPage", true);
      doQuestTrackingPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doQuestTrackingPage", true);
      doBossTrackingPage = ConfigurationEngine.setBoolean(this.fileConfiguration, "doBossTrackingPage", true);
      indexLineCreator(0, "&0&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      indexLineCreator(1, "&5&l/ag &7- &6EliteMobs Hub", "CLICK TO USE\nThe place where you can find\nNPCs that give quests, buy and\nsell items, give advice and more!", "/ag", this.fileConfiguration, this.file);
      indexLineCreator(2, "&0&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      indexLineCreator(3, "", "", "", this.fileConfiguration, this.file);
      indexLineCreator(4, "&6&lIndex", "", "", this.fileConfiguration, this.file);
      indexLineCreator(5, "", "", "", this.fileConfiguration, this.file);
      indexLineCreator(6, "&bp. $statsPage &8- &6Stats", "Click to go!", "$statsPage", this.fileConfiguration, this.file);
      indexLineCreator(7, "&bp. $gearPage &8- &6Gear", "Click to go!", "$gearPage", this.fileConfiguration, this.file);
      indexLineCreator(8, "&bp. $teleportsPage &8- &6Teleports", "Click to go!", "$teleportsPage", this.fileConfiguration, this.file);
      indexLineCreator(9, "&bp. $commandsPage &8- &6Commands", "Click to go!", "$commandsPage", this.fileConfiguration, this.file);
      indexLineCreator(10, "&bp. $questsPage &8- &6Quest Tracking", "Click to go!", "$questsPage", this.fileConfiguration, this.file);
      indexLineCreator(11, "&bp. $bossTrackingPage &8- &6Boss Tracking", "Click to go!", "$bossTrackingPage", this.fileConfiguration, this.file);
      indexLineCreator(12, "&bp. $skillsPage &8- &6Skills", "Click to go!", "$skillsPage", this.fileConfiguration, this.file);
      statsLineCreator(0, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      statsLineCreator(1, "&5&lPlayer Stats:", "", "", this.fileConfiguration, this.file);
      statsLineCreator(2, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      statsLineCreator(3, "", "", "", this.fileConfiguration, this.file);
      statsLineCreator(4, "&2Money: &a$money", "Kill Elite Mobs to loot currency or\nsell their drops in /em shop or\ncomplete quests!", "", this.fileConfiguration, this.file);
      statsLineCreator(5, "", "", "", this.fileConfiguration, this.file);
      statsLineCreator(6, "&6Guild Tier: &3$guildtier", "Prestige Tier and Guild Rank:\nGuild Rank determines how good your loot can be, sets your bonus from the Prestige Tier, among other things. The Prestige Tier unlocks extremely powerful rewards, like increased max health, chance to dodge/crit, increased currency rewards and more! You can unlock Guild Ranks and Prestige Tiers at /ag!\n⚜ = prestige rank, ✧ = guild rank!", "", this.fileConfiguration, this.file);
      statsLineCreator(7, "&4Elite Kills: &c$kills", "Amount of Elite Mobs killed.", "", this.fileConfiguration, this.file);
      statsLineCreator(8, "&4Max Lvl Killed: &c$highestkill", "Level of the highest Elite Mob killed.\nElite Mob levels are based on the tier\nof your gear! Higher tiers, higher\nElite Mob levels!\nNote: only non-exploity kills get counted!", "", this.fileConfiguration, this.file);
      statsLineCreator(9, "&4Elite Deaths: &c$deaths", "Times killed by Elite Mobs.", "", this.fileConfiguration, this.file);
      statsLineCreator(10, "&5Quests Completed: &d$quests", "Amount of EliteMobs quests completed.\nYou can accept quests by talking to NPCs!", "", this.fileConfiguration, this.file);
      statsLineCreator(11, "", "", "", this.fileConfiguration, this.file);
      statsLineCreator(12, "&bScore: &3$score", "Your EliteMobs score. It goes up\nwhen you kill and elite mob,\nand it goes down when you die\nto an elite. Higher level\nelites give more score.", "", this.fileConfiguration, this.file);
      gearLineCreator(0, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      gearLineCreator(1, "&7&lArmor & Weapons:", "", "", this.fileConfiguration, this.file);
      gearLineCreator(2, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      gearLineCreator(3, "&8&lGear Tiers:", "", "", this.fileConfiguration, this.file);
      gearLineCreator(4, "          ☠ - $helmettier", "$helmet", "", this.fileConfiguration, this.file);
      gearLineCreator(5, "          ▼ - $chestplatetier", "$chestplate", "", this.fileConfiguration, this.file);
      gearLineCreator(6, "          Π - $leggingstier", "$leggings", "", this.fileConfiguration, this.file);
      gearLineCreator(7, "          ╯╰ - $bootstier", "$boots", "", this.fileConfiguration, this.file);
      gearLineCreator(8, "{⚔ - $mainhandtier}    {⛨ - $offhandtier}", "{$mainhand}{$offhand}", "", this.fileConfiguration, this.file);
      gearLineCreator(9, "", "", "", this.fileConfiguration, this.file);
      gearLineCreator(10, "{dmg : $damage}    {armr: $armor}", "{Base damage dealt to Elite Mobs}{Damage reduction from Elite Mobs}", "", this.fileConfiguration, this.file);
      gearLineCreator(11, "Threat level: $threat", "This determines the level of the\nElite Mobs that spawns near you.\nTakes armor, weapon in hand, guild\ntier into account.\n", "", this.fileConfiguration, this.file);
      gearLineCreator(12, "", "", "", this.fileConfiguration, this.file);
      teleportLineCreator(0, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      teleportLineCreator(1, "&2&lTeleports", "", "", this.fileConfiguration, this.file);
      teleportLineCreator(2, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      teleportLineCreator(3, "&r&0Spawn", "Teleport to spawn!", "/em spawntp", this.fileConfiguration, this.file);
      teleportLineCreator(4, "&r" + PlayerStatusScreen.convertLightColorsToBlack(AdventurersGuildConfig.getAdventurersGuildMenuName()), "Teleport to the Adventurer's Guild Hub!", "/ag", this.fileConfiguration, this.file);
      onTeleportHover = ConfigurationEngine.setString(this.file, this.fileConfiguration, "onTeleportsHover", "Click to teleport!", true);
      commandsLineCreator(0, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(1, "&3&lCommands:", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(2, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(3, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(4, "&5/ag", "CLICK TO USE\nThe place where you can find\nNPCs that give quests, buy and\nsell items, give advice and more!", "/ag", this.fileConfiguration, this.file);
      commandsLineCreator(5, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(6, "&5/shareitem", "CLICK TO USE\nShares the item you're holding\non chat!", "/shareitem", this.fileConfiguration, this.file);
      commandsLineCreator(7, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(8, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(9, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(10, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(11, "", "", "", this.fileConfiguration, this.file);
      commandsLineCreator(12, "", "", "", this.fileConfiguration, this.file);
      bossTrackerLineCreator(0, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      bossTrackerLineCreator(1, "&4&lBoss Tracker:", "Big bosses get displayed here!", "", this.fileConfiguration, this.file);
      bossTrackerLineCreator(2, "&m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯", "", "", this.fileConfiguration, this.file);
      onBossTrackHover = ConfigurationEngine.setString(this.file, this.fileConfiguration, "onBossTrackHover", "Click to track/untrack!", true);
      teleportChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "teleportChestMenuName", "&2EliteMobs Teleports", true);
      bossTrackerChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "bossTrackerChestMenuName", "&2EliteMobs Boss Tracking", true);
      indexChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "indexChestMenuName", "&2EliteMobs Index", true);
      indexHeaderItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexHeaderItem", ItemStackGenerator.generateItemStack((Material)Material.PAPER, "&5&l/ag &7- &6EliteMobs Hub", new ArrayList(List.of("CLICK TO USE", "The place where you can find", "NPCs that give quests, buy and", "sell items, give advice and more!"))), true);
      indexHeaderSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexHeaderSlot", 4);
      indexStatsItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexStatsItem", ItemStackGenerator.generateItemStack(Material.MAP, "&6Stats", List.of("Click to go!")), true);
      indexStatsSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexStatsSlot", 10);
      indexGearItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexGearItem", ItemStackGenerator.generateItemStack(Material.DIAMOND_SWORD, "&6Gear", List.of("Click to go!")), true);
      indexGearSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexGearSlot", 12);
      indexTeleportsItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexTeleportsItem", ItemStackGenerator.generateItemStack(Material.END_PORTAL_FRAME, "&6Teleports", List.of("Click to go!")), true);
      indexTeleportsSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexTeleportsSlot", 14);
      indexCommandsItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexCommandsItem", ItemStackGenerator.generateItemStack(Material.JUKEBOX, "&6Commands", List.of("Click to go!")), true);
      indexCommandsSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexCommandsSlot", 16);
      indexQuestTrackingItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexQuestTrackingItem", ItemStackGenerator.generateItemStack(Material.WRITABLE_BOOK, "&6Quest Tracking", List.of("Click to go!")), true);
      indexQuestTrackingSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexQuestTrackingSlot", 20);
      indexBossTrackingItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "indexBossTrackingItem", ItemStackGenerator.generateItemStack(Material.TARGET, "&6Boss Tracking", List.of("Click to go!")), true);
      indexBossTrackingSlot = ConfigurationEngine.setInt(this.fileConfiguration, "indexBossTrackingSlot", 24);
      backItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "backItem", ItemStackGenerator.generateItemStack(Material.BARRIER, "&cBack"), true);
      gearChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "gearChestMenuName", "&2EliteMobs Gear", true);
      gearDamageItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "gearDamageItem", ItemStackGenerator.generateItemStack((Material)Material.DIAMOND_SWORD, "&4Damage: $damage", new ArrayList(List.of("&fBase damage dealt to Elites.", "&fBased on the level of your weapon!"))), true);
      gearDamageSlot = ConfigurationEngine.setInt(this.fileConfiguration, "gearDamageSlot", 23);
      gearArmorItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "gearArmorItem", ItemStackGenerator.generateItemStack((Material)Material.SHIELD, "&2Defense: $defense", new ArrayList(List.of("&fBase damage reduction from Elites.", "&fBased on the average level of your armor!"))), true);
      gearArmorSlot = ConfigurationEngine.setInt(this.fileConfiguration, "gearArmorSlot", 24);
      gearThreatItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "gearThreatItem", ItemStackGenerator.generateItemStack((Material)Material.TARGET, "&cThreat Level: $threat", new ArrayList(List.of("&fThis determines the level of the", "&fElite Mobs that spawns near you", "&fTakes armor, weapon in hand, guild", "&ftier into account."))), true);
      gearThreatSlot = ConfigurationEngine.setInt(this.fileConfiguration, "gearThreatSlot", 25);
      statsChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "statsChestMenuName", "&2EliteMobs Stats", true);
      statsMoneyItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsMoneyItem", ItemStackGenerator.generateItemStack((Material)Material.GOLD_INGOT, "&2Elite Coins: $money", new ArrayList(List.of("&fKill Elite Mobs to loot currency,", "&fsell their drops in /em shop or", "&fcomplete quests!"))), true);
      statsMoneySlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsMoneySlot", 10);
      statsGuildTierItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsGuildTierItem", ItemStackGenerator.generateItemStack((Material)Material.TARGET, "&6Guild Tier: $tier", new ArrayList(List.of("&fGuild Rank determines how good your loot can ", "&fbe, sets your bonus from the Prestige Tier, among ", "&fother things. The Prestige Tier unlocks extremely ", "&fpowerful rewards, like increased max health, chance ", "&fto dodge/crit, increased currency rewards and more! ", "&fYou can unlock Guild Ranks and Prestige Tiers at /ag!", "&f⚜ = prestige rank, ✧ = guild rank!"))), true);
      statsGuildTierSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsGuildTierSlot", 11);
      statsEliteKillsItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsEliteKillsItem", ItemStackGenerator.generateItemStack(Material.DIAMOND_SWORD, "&4Elite Kills: &c$kills", List.of("&fAmount of EliteMobs killed.")), true);
      statsEliteKillsSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsEliteKillsSlot", 12);
      statsMaxEliteLevelKilledItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsMaxEliteLevelKilledItem", ItemStackGenerator.generateItemStack((Material)Material.GOLDEN_SWORD, "&4Max Lvl Killed: &c$maxKill", new ArrayList(List.of("&fElite Mob levels are based on the tier", "&fof your gear! Higher tiers, higher", "&fElite Mob levels!\n", "&eNote: only non-exploity kills get counted!"))), true);
      statsMaxEliteLevelKilledSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsMaxEliteLevelKilledSlot", 13);
      statsEliteDeathsItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsEliteDeathsItem", ItemStackGenerator.generateItemStack(Material.TOTEM_OF_UNDYING, "&4Elite Deaths: $deaths", List.of("&fTimes killed by Elite Mobs.")), true);
      statsEliteDeathsSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsEliteDeathsSlot", 14);
      statsQuestsCompletedItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsQuestsCompletedItem", ItemStackGenerator.generateItemStack((Material)Material.LECTERN, "&5Quests Completed: &d$questsCompleted", new ArrayList(List.of("&fAmount of EliteMobs quests completed.", "&fYou can accept quests by talking to NPCs!"))), true);
      statsQuestsCompletedSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsQuestsCompletedSlot", 15);
      statsScoreItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "statsScoreItem", ItemStackGenerator.generateItemStack((Material)Material.ITEM_FRAME, "&3Score: &b$score", new ArrayList(List.of("&fYour EliteMobs score. It goes up", "&fwhen you kill and elite mob,", "&fand it goes down when you die", "&fto an elite. Higher level", "&felites give more score."))), true);
      statsScoreSlot = ConfigurationEngine.setInt(this.fileConfiguration, "statsScoreSlot", 16);
      commandsChestMenuName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "commandsChestMenuName", "&2EliteMobs Commands", true);
      commandsAGItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "commandsAGItem", ItemStackGenerator.generateItemStack((Material)Material.END_PORTAL_FRAME, "&5/ag", new ArrayList(List.of("&fClick to use!", "&fThe place where you can find", "&fNPCs that give quests, buy and", "&fsell items, give advice and more!"))), true);
      commandsAGSlot = ConfigurationEngine.setInt(this.fileConfiguration, "commandsAGSlot", 11);
      commandsShareItemItem = ConfigurationEngine.setItemStack(this.file, this.fileConfiguration, "commandsShareItemItem", ItemStackGenerator.generateItemStack((Material)Material.PAPER, "&5/shareitem", new ArrayList(List.of("&fClick to use!", "&fShares the Elite Item you're holding", "&fon chat!"))), true);
      commandsShareItemSlot = ConfigurationEngine.setInt(this.fileConfiguration, "commandsShareItemSlot", 15);
      skillsItemDisplayName = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsItemDisplayName", "&5&lSkills", true);
      skillsItemLore1 = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsItemLore1", "&7View your skill levels", true);
      skillsItemLore2 = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsItemLore2", "&7and XP progress.", true);
      skillsItemClickLore = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsItemClickLore", "&eClick to view!", true);
      skillsPageHeader = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsPageHeader", "&5&lYour Skills", true);
      skillsPageLevelFormat = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsPageLevelFormat", "&6$skillName &7Lv.&e$level", true);
      skillsPageXpFormat = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillsPageXpFormat", "&8$progressBar &7$currentXp/$nextXp", true);
      skillItemDisplayNameFormat = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillItemDisplayNameFormat", "&6&lLevel $level $skillName", true);
      skillItemSelectLore1 = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillItemSelectLore1", "&eClick to select passive skills", true);
      skillItemSelectLore2 = ConfigurationEngine.setString(this.file, this.fileConfiguration, "skillItemSelectLore2", "&eand see more details!", true);
      dialogTitlePlayerStatus = ConfigurationEngine.setString(List.of("Title for the main player status dialog menu."), this.file, this.fileConfiguration, "dialog.titlePlayerStatus", "Player Status Menu", true);
      dialogTitleStats = ConfigurationEngine.setString(List.of("Title for the Stats dialog section."), this.file, this.fileConfiguration, "dialog.titleStats", "Stats", true);
      dialogTitleGear = ConfigurationEngine.setString(List.of("Title for the Gear dialog section."), this.file, this.fileConfiguration, "dialog.titleGear", "Gear", true);
      dialogTitleTeleports = ConfigurationEngine.setString(List.of("Title for the Teleports dialog section."), this.file, this.fileConfiguration, "dialog.titleTeleports", "Teleports", true);
      dialogTitleCommands = ConfigurationEngine.setString(List.of("Title for the Commands dialog section."), this.file, this.fileConfiguration, "dialog.titleCommands", "Commands", true);
      dialogTitleQuests = ConfigurationEngine.setString(List.of("Title for the Quests dialog section."), this.file, this.fileConfiguration, "dialog.titleQuests", "Quests", true);
      dialogTitleBossTracking = ConfigurationEngine.setString(List.of("Title for the Boss Tracking dialog section."), this.file, this.fileConfiguration, "dialog.titleBossTracking", "Boss Tracking", true);
      dialogTitleSkills = ConfigurationEngine.setString(List.of("Title for the Skills dialog section."), this.file, this.fileConfiguration, "dialog.titleSkills", "Skills", true);
      dialogNoActiveQuests = ConfigurationEngine.setString(List.of("Message shown when the player has no active quests."), this.file, this.fileConfiguration, "dialog.noActiveQuests", "No active quests", true);
      dialogActiveQuestsFormat = ConfigurationEngine.setString(List.of("Message showing the number of active quests. Use $amount for the quest count."), this.file, this.fileConfiguration, "dialog.activeQuestsFormat", "You have $amount active quest(s).", true);
      dialogBackButton = ConfigurationEngine.setString(List.of("Text for the back button in dialog sections."), this.file, this.fileConfiguration, "dialog.backButton", "← Back to Menu", true);
   }

   @Generated
   public static String[] getIndexTextLines() {
      return indexTextLines;
   }

   @Generated
   public static String[] getIndexHoverLines() {
      return indexHoverLines;
   }

   @Generated
   public static String[] getIndexCommandLines() {
      return indexCommandLines;
   }

   @Generated
   public static String[] getStatsTextLines() {
      return statsTextLines;
   }

   @Generated
   public static String[] getStatsHoverLines() {
      return statsHoverLines;
   }

   @Generated
   public static String[] getStatsCommandLines() {
      return statsCommandLines;
   }

   @Generated
   public static String[] getGearTextLines() {
      return gearTextLines;
   }

   @Generated
   public static String[] getGearHoverLines() {
      return gearHoverLines;
   }

   @Generated
   public static String[] getTeleportTextLines() {
      return teleportTextLines;
   }

   @Generated
   public static String[] getTeleportHoverLines() {
      return teleportHoverLines;
   }

   @Generated
   public static String[] getTeleportCommandLines() {
      return teleportCommandLines;
   }

   @Generated
   public static String[] getCommandsTextLines() {
      return commandsTextLines;
   }

   @Generated
   public static String[] getCommandsHoverLines() {
      return commandsHoverLines;
   }

   @Generated
   public static String[] getCommandsCommandLines() {
      return commandsCommandLines;
   }

   @Generated
   public static String[] getBossTrackerTextLines() {
      return bossTrackerTextLines;
   }

   @Generated
   public static String[] getBossTrackerHoverLines() {
      return bossTrackerHoverLines;
   }

   @Generated
   public static String[] getBossTrackerCommandLines() {
      return bossTrackerCommandLines;
   }

   @Generated
   public static boolean isDoStatsPage() {
      return doStatsPage;
   }

   @Generated
   public static boolean isDoGearPage() {
      return doGearPage;
   }

   @Generated
   public static boolean isDoTeleportsPage() {
      return doTeleportsPage;
   }

   @Generated
   public static boolean isDoCommandsPage() {
      return doCommandsPage;
   }

   @Generated
   public static boolean isDoQuestTrackingPage() {
      return doQuestTrackingPage;
   }

   @Generated
   public static boolean isDoBossTrackingPage() {
      return doBossTrackingPage;
   }

   @Generated
   public static String getTeleportChestMenuName() {
      return teleportChestMenuName;
   }

   @Generated
   public static String getBossTrackerChestMenuName() {
      return bossTrackerChestMenuName;
   }

   @Generated
   public static String getOnBossTrackHover() {
      return onBossTrackHover;
   }

   @Generated
   public static String getOnTeleportHover() {
      return onTeleportHover;
   }

   @Generated
   public static String getIndexChestMenuName() {
      return indexChestMenuName;
   }

   @Generated
   public static ItemStack getBackItem() {
      return backItem;
   }

   @Generated
   public static ItemStack getIndexHeaderItem() {
      return indexHeaderItem;
   }

   @Generated
   public static int getIndexHeaderSlot() {
      return indexHeaderSlot;
   }

   @Generated
   public static ItemStack getIndexStatsItem() {
      return indexStatsItem;
   }

   @Generated
   public static int getIndexStatsSlot() {
      return indexStatsSlot;
   }

   @Generated
   public static ItemStack getIndexGearItem() {
      return indexGearItem;
   }

   @Generated
   public static int getIndexGearSlot() {
      return indexGearSlot;
   }

   @Generated
   public static ItemStack getIndexTeleportsItem() {
      return indexTeleportsItem;
   }

   @Generated
   public static int getIndexTeleportsSlot() {
      return indexTeleportsSlot;
   }

   @Generated
   public static ItemStack getIndexCommandsItem() {
      return indexCommandsItem;
   }

   @Generated
   public static int getIndexCommandsSlot() {
      return indexCommandsSlot;
   }

   @Generated
   public static ItemStack getIndexQuestTrackingItem() {
      return indexQuestTrackingItem;
   }

   @Generated
   public static int getIndexQuestTrackingSlot() {
      return indexQuestTrackingSlot;
   }

   @Generated
   public static ItemStack getIndexBossTrackingItem() {
      return indexBossTrackingItem;
   }

   @Generated
   public static int getIndexBossTrackingSlot() {
      return indexBossTrackingSlot;
   }

   @Generated
   public static String getGearChestMenuName() {
      return gearChestMenuName;
   }

   @Generated
   public static ItemStack getGearDamageItem() {
      return gearDamageItem;
   }

   @Generated
   public static int getGearDamageSlot() {
      return gearDamageSlot;
   }

   @Generated
   public static ItemStack getGearArmorItem() {
      return gearArmorItem;
   }

   @Generated
   public static int getGearArmorSlot() {
      return gearArmorSlot;
   }

   @Generated
   public static ItemStack getGearThreatItem() {
      return gearThreatItem;
   }

   @Generated
   public static int getGearThreatSlot() {
      return gearThreatSlot;
   }

   @Generated
   public static String getStatsChestMenuName() {
      return statsChestMenuName;
   }

   @Generated
   public static ItemStack getStatsMoneyItem() {
      return statsMoneyItem;
   }

   @Generated
   public static int getStatsMoneySlot() {
      return statsMoneySlot;
   }

   @Generated
   public static ItemStack getStatsGuildTierItem() {
      return statsGuildTierItem;
   }

   @Generated
   public static int getStatsGuildTierSlot() {
      return statsGuildTierSlot;
   }

   @Generated
   public static ItemStack getStatsEliteKillsItem() {
      return statsEliteKillsItem;
   }

   @Generated
   public static int getStatsEliteKillsSlot() {
      return statsEliteKillsSlot;
   }

   @Generated
   public static ItemStack getStatsMaxEliteLevelKilledItem() {
      return statsMaxEliteLevelKilledItem;
   }

   @Generated
   public static int getStatsMaxEliteLevelKilledSlot() {
      return statsMaxEliteLevelKilledSlot;
   }

   @Generated
   public static ItemStack getStatsEliteDeathsItem() {
      return statsEliteDeathsItem;
   }

   @Generated
   public static int getStatsEliteDeathsSlot() {
      return statsEliteDeathsSlot;
   }

   @Generated
   public static ItemStack getStatsQuestsCompletedItem() {
      return statsQuestsCompletedItem;
   }

   @Generated
   public static int getStatsQuestsCompletedSlot() {
      return statsQuestsCompletedSlot;
   }

   @Generated
   public static ItemStack getStatsScoreItem() {
      return statsScoreItem;
   }

   @Generated
   public static int getStatsScoreSlot() {
      return statsScoreSlot;
   }

   @Generated
   public static String getCommandsChestMenuName() {
      return commandsChestMenuName;
   }

   @Generated
   public static ItemStack getCommandsAGItem() {
      return commandsAGItem;
   }

   @Generated
   public static int getCommandsAGSlot() {
      return commandsAGSlot;
   }

   @Generated
   public static ItemStack getCommandsShareItemItem() {
      return commandsShareItemItem;
   }

   @Generated
   public static int getCommandsShareItemSlot() {
      return commandsShareItemSlot;
   }

   @Generated
   public static String getSkillsItemDisplayName() {
      return skillsItemDisplayName;
   }

   @Generated
   public static String getSkillsItemLore1() {
      return skillsItemLore1;
   }

   @Generated
   public static String getSkillsItemLore2() {
      return skillsItemLore2;
   }

   @Generated
   public static String getSkillsItemClickLore() {
      return skillsItemClickLore;
   }

   @Generated
   public static String getSkillsPageHeader() {
      return skillsPageHeader;
   }

   @Generated
   public static String getSkillsPageLevelFormat() {
      return skillsPageLevelFormat;
   }

   @Generated
   public static String getSkillsPageXpFormat() {
      return skillsPageXpFormat;
   }

   @Generated
   public static String getSkillItemDisplayNameFormat() {
      return skillItemDisplayNameFormat;
   }

   @Generated
   public static String getSkillItemSelectLore1() {
      return skillItemSelectLore1;
   }

   @Generated
   public static String getSkillItemSelectLore2() {
      return skillItemSelectLore2;
   }

   @Generated
   public static String getDialogTitlePlayerStatus() {
      return dialogTitlePlayerStatus;
   }

   @Generated
   public static String getDialogTitleStats() {
      return dialogTitleStats;
   }

   @Generated
   public static String getDialogTitleGear() {
      return dialogTitleGear;
   }

   @Generated
   public static String getDialogTitleTeleports() {
      return dialogTitleTeleports;
   }

   @Generated
   public static String getDialogTitleCommands() {
      return dialogTitleCommands;
   }

   @Generated
   public static String getDialogTitleQuests() {
      return dialogTitleQuests;
   }

   @Generated
   public static String getDialogTitleBossTracking() {
      return dialogTitleBossTracking;
   }

   @Generated
   public static String getDialogTitleSkills() {
      return dialogTitleSkills;
   }

   @Generated
   public static String getDialogNoActiveQuests() {
      return dialogNoActiveQuests;
   }

   @Generated
   public static String getDialogActiveQuestsFormat() {
      return dialogActiveQuestsFormat;
   }

   @Generated
   public static String getDialogBackButton() {
      return dialogBackButton;
   }
}
