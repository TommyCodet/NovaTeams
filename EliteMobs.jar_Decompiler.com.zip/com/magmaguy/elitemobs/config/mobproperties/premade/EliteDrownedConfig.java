package com.magmaguy.elitemobs.config.mobproperties.premade;

import com.magmaguy.elitemobs.config.mobproperties.MobPropertiesConfigFields;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.EntityType;

public class EliteDrownedConfig extends MobPropertiesConfigFields {
   public EliteDrownedConfig() {
      super("elite_drowned", EntityType.DROWNED, true, "&fLvl &2$level &fElite &3Drowned", new ArrayList(List.of("$player &chas been brought down to the depths by $entity!", "$player &chas been drowned by $entity!")), (double)4.0F);
   }
}
