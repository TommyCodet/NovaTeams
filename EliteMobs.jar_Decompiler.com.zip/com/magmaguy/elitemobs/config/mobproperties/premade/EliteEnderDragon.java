package com.magmaguy.elitemobs.config.mobproperties.premade;

import com.magmaguy.elitemobs.config.mobproperties.MobPropertiesConfigFields;
import java.util.List;
import org.bukkit.entity.EntityType;

public class EliteEnderDragon extends MobPropertiesConfigFields {
   public EliteEnderDragon() {
      super("elite_ender_dragon", EntityType.ENDER_DRAGON, true, "&fLvl &2$level &fElite &5Ender Dragon", List.of("$entity &chas ended $player!"), (double)7.0F);
   }
}
