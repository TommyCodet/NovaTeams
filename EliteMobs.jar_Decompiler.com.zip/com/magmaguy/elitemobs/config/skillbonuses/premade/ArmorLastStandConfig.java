package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class ArmorLastStandConfig extends SkillBonusConfigFields {
   public ArmorLastStandConfig() {
      super("armor_last_stand.yml", true, "&4Last Stand", List.of("&7Survive fatal damage with", "&71 heart. 120s cooldown."), SkillType.ARMOR, 4, (double)1.0F, 0.02, (double)0.0F, (double)120.0F, Material.TOTEM_OF_UNDYING, true);
      this.loreTemplates = List.of("&7Survive a fatal blow once per cooldown", "&7Prevents death and restores you to 1 HP", "&7Cooldown: $cooldown");
      this.formattedBonusTemplate = "Prevent death (CD: $cooldown)";
   }
}
