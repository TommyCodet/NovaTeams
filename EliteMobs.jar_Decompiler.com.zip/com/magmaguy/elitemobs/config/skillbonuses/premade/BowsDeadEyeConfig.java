package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class BowsDeadEyeConfig extends SkillBonusConfigFields {
   public BowsDeadEyeConfig() {
      super("bows_dead_eye.yml", true, "&4Dead Eye", List.of("&7Critical hits deal massive", "&7bonus damage. 45s cooldown."), SkillType.BOWS, 4, (double)1.5F, 0.03, (double)0.0F, (double)45.0F, Material.ENDER_EYE, true);
      this.loreTemplates = List.of("&7Damage Multiplier: &f$damageMultiplierx", "&7Cooldown: &f$cooldowns", "&7Triggers on critical hits");
      this.formattedBonusTemplate = "$damageMultiplierx critical damage";
   }
}
