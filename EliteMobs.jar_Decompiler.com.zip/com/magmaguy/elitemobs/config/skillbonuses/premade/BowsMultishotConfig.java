package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class BowsMultishotConfig extends SkillBonusConfigFields {
   public BowsMultishotConfig() {
      super("bows_multishot.yml", true, "&dMultishot", List.of("&7Chance to fire additional", "&7arrows on each shot."), SkillType.BOWS, 2, (double)0.0F, (double)0.0F, 0.2, (double)0.0F, Material.SPECTRAL_ARROW, false);
      this.loreTemplates = List.of("&7Proc Chance: &f$procChance%", "&7Extra Arrows: &f$extraArrows", "&7Arrow Damage: &f50% of original");
      this.formattedBonusTemplate = "$procChance% chance for extra arrows";
   }
}
