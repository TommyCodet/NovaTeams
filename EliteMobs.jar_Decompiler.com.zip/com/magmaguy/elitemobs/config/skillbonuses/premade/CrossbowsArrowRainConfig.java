package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class CrossbowsArrowRainConfig extends SkillBonusConfigFields {
   public CrossbowsArrowRainConfig() {
      super("crossbows_arrow_rain.yml", true, "&9Arrow Rain", List.of("&7Rain arrows on your target.", "&730s cooldown."), SkillType.CROSSBOWS, 4, (double)1.0F, 0.02, (double)0.0F, (double)30.0F, Material.CROSSBOW, true);
      this.loreTemplates = List.of("&7Arrow Damage: &f$arrowDamage%", "&7Arrows: &f15 total (3x5 waves)", "&7Cooldown: &f$cooldowns");
      this.formattedBonusTemplate = "$arrowDamage% arrow damage";
   }
}
