package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import com.magmaguy.elitemobs.skills.bonuses.SkillBonusType;
import java.util.List;
import org.bukkit.Material;

public class CrossbowsFirstBloodConfig extends SkillBonusConfigFields {
   public CrossbowsFirstBloodConfig() {
      super("crossbows_first_blood.yml", true, "&4First Blood", List.of("&7Deal massive bonus damage", "&7with the first hit on an enemy."), SkillType.CROSSBOWS, SkillBonusType.CONDITIONAL, 4, (double)0.75F, 0.015, Material.REDSTONE);
      this.loreTemplates = List.of("&7First Hit Bonus: &f$value%", "&7Triggers on full health targets");
      this.formattedBonusTemplate = "+$value% first hit damage";
   }
}
