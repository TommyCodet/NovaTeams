package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class HoesSpectralScytheConfig extends SkillBonusConfigFields {
   public HoesSpectralScytheConfig() {
      super("hoes_spectral_scythe.yml", true, "&bSpectral Scythe", List.of("&7Launch a spectral scythe", "&7projectile. 25s CD."), SkillType.HOES, 4, (double)1.5F, 0.03, (double)0.0F, (double)25.0F, Material.PHANTOM_MEMBRANE, true);
      this.loreTemplates = List.of("&7Damage: &f$damagePercent% weapon damage", "&7Range: &f$range blocks", "&7Cooldown: &f$cooldown seconds", "&7Pierces through enemies");
      this.formattedBonusTemplate = "$damagePercent% Projectile Damage";
   }
}
