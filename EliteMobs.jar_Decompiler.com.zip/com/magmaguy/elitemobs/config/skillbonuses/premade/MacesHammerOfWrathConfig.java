package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class MacesHammerOfWrathConfig extends SkillBonusConfigFields {
   public MacesHammerOfWrathConfig() {
      super("maces_hammer_of_wrath.yml", true, "&eHammer of Wrath", List.of("&7Deal massive damage to", "&7enemies below 30% health. 30s CD."), SkillType.MACES, 4, (double)3.0F, 0.05, (double)0.0F, (double)30.0F, Material.NETHERITE_BLOCK, true);
      this.loreTemplates = List.of("&7Damage: &f$damage%", "&7Threshold: &f<30% HP", "&7Cooldown: &f$cooldowns");
      this.formattedBonusTemplate = "$damage% vs Low HP (CD: $cooldowns)";
   }
}
