package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class SpearsImpalerConfig extends SkillBonusConfigFields {
   public SpearsImpalerConfig() {
      super("spears_impaler.yml", true, "&b&lImpaler", List.of("&7Pin an enemy in place,", "&7dealing massive damage. 45s CD."), SkillType.SPEARS, 4, (double)4.0F, 0.05, (double)0.0F, (double)45.0F, Material.END_ROD, true);
      this.loreTemplates = List.of("&7Damage: &f$damage%", "&7Pin Duration: &f3 seconds", "&7Cooldown: &f$cooldowns");
      this.formattedBonusTemplate = "$damage% + Pin (CD: $cooldowns)";
   }
}
