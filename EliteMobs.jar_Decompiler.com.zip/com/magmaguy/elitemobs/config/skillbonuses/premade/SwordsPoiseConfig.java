package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import com.magmaguy.elitemobs.skills.bonuses.SkillBonusType;
import java.util.List;
import org.bukkit.Material;

public class SwordsPoiseConfig extends SkillBonusConfigFields {
   public SwordsPoiseConfig() {
      super("swords_poise.yml", true, "&aPoise", List.of("&7Reduces knockback taken while", "&7wielding a sword."), SkillType.SWORDS, SkillBonusType.PASSIVE, 1, 0.2, 0.003, Material.IRON_BOOTS);
      this.loreTemplates = List.of("&7Knockback Reduction: &f$value%", "&7Always active when selected");
      this.formattedBonusTemplate = "-$value% Knockback";
   }
}
