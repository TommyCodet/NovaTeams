package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class TridentsSnareConfig extends SkillBonusConfigFields {
   public TridentsSnareConfig() {
      super("tridents_snare.yml", true, "&bSnare", List.of("&7Chance to root enemies", "&7in place temporarily."), SkillType.TRIDENTS, 1, (double)1.0F, 0.02, (double)0.25F, (double)0.0F, Material.COBWEB, false);
      this.loreTemplates = List.of("&7Chance: &f$procChance%", "&7Slowness Level: &f$slownessLevel", "&7Duration: &f3 seconds");
      this.formattedBonusTemplate = "Slowness $slownessLevel";
   }
}
