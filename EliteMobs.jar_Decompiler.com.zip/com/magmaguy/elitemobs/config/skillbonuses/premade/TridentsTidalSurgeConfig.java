package com.magmaguy.elitemobs.config.skillbonuses.premade;

import com.magmaguy.elitemobs.config.skillbonuses.SkillBonusConfigFields;
import com.magmaguy.elitemobs.skills.SkillType;
import java.util.List;
import org.bukkit.Material;

public class TridentsTidalSurgeConfig extends SkillBonusConfigFields {
   public TridentsTidalSurgeConfig() {
      super("tridents_tidal_surge.yml", true, "&9Tidal Surge", List.of("&7Create a wave that knocks", "&7back nearby enemies. 20s CD."), SkillType.TRIDENTS, 2, (double)1.0F, 0.02, (double)0.0F, (double)20.0F, Material.WATER_BUCKET, true);
      this.loreTemplates = List.of("&7Cooldown: &f$cooldowns", "&7Knockback: &f$knockback", "&7Radius: &f$radius blocks");
      this.formattedBonusTemplate = "$knockback Knockback";
   }
}
