package com.magmaguy.elitemobs.config.translations;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslationCsvParser {
   private static final Pattern LIST_INDEX_PATTERN = Pattern.compile("^(.+)\\[(\\d+)]$");

   public static TranslationData parse(File file) throws IOException {
      return parse(file.toPath());
   }

   public static TranslationData parse(Path path) throws IOException {
      List<String[]> rows = new ArrayList();
      BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);

      try {
         StringBuilder currentRow = new StringBuilder();
         boolean inQuotes = false;
         boolean firstLine = true;

         String line;
         while((line = reader.readLine()) != null) {
            if (firstLine) {
               firstLine = false;
               if (line.length() > 0 && line.charAt(0) == '\ufeff') {
                  line = line.substring(1);
               }
            }

            if ((currentRow.length() != 0 || !line.trim().isEmpty()) && (currentRow.length() != 0 || !line.trim().startsWith("#"))) {
               currentRow.append(line);

               for(char c : line.toCharArray()) {
                  if (c == '"') {
                     inQuotes = !inQuotes;
                  }
               }

               if (!inQuotes) {
                  String[] fields = parseCSVRow(currentRow.toString());
                  if (fields.length > 0) {
                     rows.add(fields);
                  }

                  currentRow = new StringBuilder();
               } else {
                  currentRow.append("\n");
               }
            }
         }
      } catch (Throwable var19) {
         if (reader != null) {
            try {
               reader.close();
            } catch (Throwable var18) {
               var19.addSuppressed(var18);
            }
         }

         throw var19;
      }

      if (reader != null) {
         reader.close();
      }

      if (rows.isEmpty()) {
         throw new IOException("CSV file is empty or has no valid rows");
      } else {
         String[] header = (String[])rows.get(0);
         if (header.length < 2) {
            throw new IOException("CSV header must have at least 'key' and one language column");
         } else {
            List<String> languages = new ArrayList();

            for(int i = 1; i < header.length; ++i) {
               languages.add(header[i].trim().toLowerCase());
            }

            TranslationData data = new TranslationData(languages);
            Map<String, Map<String, TreeMap<Integer, String>>> indexedEntries = new LinkedHashMap();

            for(int rowIndex = 1; rowIndex < rows.size(); ++rowIndex) {
               String[] row = (String[])rows.get(rowIndex);
               if (row.length != 0 && !row[0].trim().isEmpty()) {
                  String rawKey = row[0].trim();
                  Matcher matcher = LIST_INDEX_PATTERN.matcher(rawKey);
                  if (matcher.matches()) {
                     String baseKey = matcher.group(1);
                     int index = Integer.parseInt(matcher.group(2));

                     for(int langIdx = 0; langIdx < languages.size() && langIdx + 1 < row.length; ++langIdx) {
                        String language = (String)languages.get(langIdx);
                        String value = row[langIdx + 1];
                        ((TreeMap)((Map)indexedEntries.computeIfAbsent(baseKey, (k) -> new LinkedHashMap())).computeIfAbsent(language, (k) -> new TreeMap())).put(index, value);
                     }
                  } else {
                     for(int langIdx = 0; langIdx < languages.size() && langIdx + 1 < row.length; ++langIdx) {
                        String language = (String)languages.get(langIdx);
                        String value = row[langIdx + 1];
                        data.set(rawKey, language, value);
                     }
                  }
               }
            }

            for(Map.Entry<String, Map<String, TreeMap<Integer, String>>> keyEntry : indexedEntries.entrySet()) {
               String baseKey = (String)keyEntry.getKey();

               for(Map.Entry<String, TreeMap<Integer, String>> langEntry : ((Map)keyEntry.getValue()).entrySet()) {
                  String language = (String)langEntry.getKey();
                  TreeMap<Integer, String> indexMap = (TreeMap)langEntry.getValue();
                  List<String> list = new ArrayList();
                  int expectedIndex = 0;

                  for(Map.Entry<Integer, String> indexEntry : indexMap.entrySet()) {
                     int index = (Integer)indexEntry.getKey();

                     while(list.size() < index) {
                        list.add("");
                     }

                     list.add((String)indexEntry.getValue());
                     expectedIndex = index + 1;
                  }

                  data.set(baseKey, language, list);
               }
            }

            return data;
         }
      }
   }

   private static String[] parseCSVRow(String row) {
      List<String> fields = new ArrayList();
      StringBuilder current = new StringBuilder();
      boolean inQuotes = false;
      boolean hadQuotes = false;

      for(int i = 0; i < row.length(); ++i) {
         char c = row.charAt(i);
         if (inQuotes) {
            if (c == '"') {
               if (i + 1 < row.length() && row.charAt(i + 1) == '"') {
                  current.append('"');
                  ++i;
               } else {
                  inQuotes = false;
               }
            } else {
               current.append(c);
            }
         } else if (c == '"') {
            inQuotes = true;
            hadQuotes = true;
         } else if (c == ',') {
            fields.add(current.toString());
            current = new StringBuilder();
            hadQuotes = false;
         } else {
            current.append(c);
         }
      }

      fields.add(current.toString());
      return (String[])fields.toArray(new String[0]);
   }

   public static void write(TranslationData data, File file) throws IOException {
      write(data, file.toPath());
   }

   public static void write(TranslationData data, Path path) throws IOException {
      Files.createDirectories(path.getParent());
      BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8);

      try {
         writer.write(65279);
         List<String> languages = data.getLanguages();
         writer.write(escapeCSV("key"));

         for(String lang : languages) {
            writer.write(",");
            writer.write(escapeCSV(lang));
         }

         writer.newLine();
         List<String> sortedKeys = new ArrayList(data.getKeys());
         Collections.sort(sortedKeys);

         for(String key : sortedKeys) {
            Object firstValue = null;

            for(String lang : languages) {
               firstValue = data.get(key, lang);
               if (firstValue != null) {
                  break;
               }
            }

            if (firstValue instanceof List) {
               int maxSize = 0;

               for(String lang : languages) {
                  List<String> list = data.getList(key, lang);
                  if (list != null) {
                     maxSize = Math.max(maxSize, list.size());
                  }
               }

               for(int i = 0; i < maxSize; ++i) {
                  writer.write(escapeCSV(key + "[" + i + "]"));

                  for(String lang : languages) {
                     writer.write(",");
                     List<String> list = data.getList(key, lang);
                     if (list != null && i < list.size()) {
                        writer.write(escapeCSV((String)list.get(i)));
                     } else {
                        writer.write("\"\"");
                     }
                  }

                  writer.newLine();
               }
            } else {
               writer.write(escapeCSV(key));

               for(String lang : languages) {
                  writer.write(",");
                  String value = data.getString(key, lang);
                  writer.write(escapeCSV(value != null ? value : ""));
               }

               writer.newLine();
            }
         }
      } catch (Throwable var14) {
         if (writer != null) {
            try {
               writer.close();
            } catch (Throwable var13) {
               var14.addSuppressed(var13);
            }
         }

         throw var14;
      }

      if (writer != null) {
         writer.close();
      }

   }

   private static String escapeCSV(String value) {
      if (value == null) {
         return "\"\"";
      } else {
         StringBuilder sb = new StringBuilder();
         sb.append('"');

         for(char c : value.toCharArray()) {
            if (c == '"') {
               sb.append("\"\"");
            } else {
               sb.append(c);
            }
         }

         sb.append('"');
         return sb.toString();
      }
   }

   public static void mergeNewKeys(TranslationData existing, TranslationData additions) {
      for(String key : additions.getKeys()) {
         if (!existing.hasKey(key)) {
            for(String lang : additions.getLanguages()) {
               Object value = additions.get(key, lang);
               if (value != null) {
                  existing.addLanguage(lang);
                  existing.set(key, lang, value);
               }
            }
         }
      }

   }

   public static class TranslationData {
      private final List<String> languages;
      private final Map<String, Map<String, Object>> translations;

      public TranslationData(List<String> languages) {
         this.languages = new ArrayList(languages);
         this.translations = new LinkedHashMap();
      }

      public List<String> getLanguages() {
         return Collections.unmodifiableList(this.languages);
      }

      public Object get(String key, String language) {
         Map<String, Object> langMap = (Map)this.translations.get(key);
         return langMap == null ? null : langMap.get(language);
      }

      public String getString(String key, String language) {
         Object value = this.get(key, language);
         return value instanceof String ? (String)value : null;
      }

      public List<String> getList(String key, String language) {
         Object value = this.get(key, language);
         return value instanceof List ? (List)value : null;
      }

      public void set(String key, String language, Object value) {
         ((Map)this.translations.computeIfAbsent(key, (k) -> new LinkedHashMap())).put(language, value);
      }

      public boolean hasKey(String key) {
         return this.translations.containsKey(key);
      }

      public Set<String> getKeys() {
         return Collections.unmodifiableSet(this.translations.keySet());
      }

      public void addLanguage(String language) {
         if (!this.languages.contains(language)) {
            this.languages.add(language);
         }

      }
   }
}
