package com.magmaguy.elitemobs.config.translations;

import com.magmaguy.elitemobs.config.DefaultConfig;
import com.magmaguy.elitemobs.magmacore.util.ChatColorConverter;
import com.magmaguy.elitemobs.magmacore.util.Logger;
import java.util.List;
import lombok.Generated;

public class TranslationsConfig {
   private static TranslationsConfigFields translationsConfigFields;

   public TranslationsConfig() {
      if (isEnglish()) {
         translationsConfigFields = null;
         Logger.info("Language set to English - using plugin defaults");
      } else {
         translationsConfigFields = new TranslationsConfigFields();
      }

   }

   public static String add(String filename, String key, String value) {
      if (isEnglish()) {
         return ChatColorConverter.convert(value);
      } else if (translationsConfigFields == null) {
         Logger.warn("TranslationsConfig not initialized, defaulting to English! (String)");
         return ChatColorConverter.convert(value);
      } else {
         translationsConfigFields.add(filename, key, value);
         Object result = translationsConfigFields.get(filename, key);
         return result instanceof String ? (String)result : ChatColorConverter.convert(value);
      }
   }

   public static List<String> add(String filename, String key, List<String> value) {
      if (isEnglish()) {
         return ChatColorConverter.convert(value);
      } else if (translationsConfigFields == null) {
         Logger.warn("TranslationsConfig not initialized, defaulting to English! (List)");
         return ChatColorConverter.convert(value);
      } else {
         translationsConfigFields.add(filename, key, value);
         Object result = translationsConfigFields.get(filename, key);
         return result instanceof List ? (List)result : ChatColorConverter.convert(value);
      }
   }

   public static boolean isEnglish() {
      String lang = DefaultConfig.getLanguage();
      if (lang == null) {
         return true;
      } else {
         lang = lang.toLowerCase().replace(".yml", "").replace(".csv", "");
         return lang.equals("english") || lang.equals("en");
      }
   }

   public static void shutdown() {
      if (translationsConfigFields != null) {
         translationsConfigFields.shutdown();
      }

   }

   @Generated
   public static TranslationsConfigFields getTranslationsConfigFields() {
      return translationsConfigFields;
   }
}
