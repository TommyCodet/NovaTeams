package com.magmaguy.elitemobs.config.translations;

import com.magmaguy.elitemobs.MetadataHandler;
import com.magmaguy.elitemobs.config.DefaultConfig;
import com.magmaguy.elitemobs.magmacore.util.ChatColorConverter;
import com.magmaguy.elitemobs.magmacore.util.Logger;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import org.bukkit.Bukkit;

public class TranslationsConfigFields {
   private static final String TRANSLATIONS_DATA_SUFFIX = "_data.csv";
   private final String languageName;
   private final String languageCode;
   private TranslationCsvParser.TranslationData translationData;
   private TranslationCsvParser.TranslationData translationDataSnapshot;
   private Path translationsPath;
   private Path translationsDataPath;
   private boolean saving = false;
   private boolean dirty = false;

   public TranslationsConfigFields() {
      String configLang = DefaultConfig.getLanguage();
      this.languageName = configLang.replace(".yml", "").replace(".csv", "");
      this.languageCode = this.getLanguageCode(this.languageName.toLowerCase());
      this.initialize();
   }

   private String getLanguageCode(String languageName) {
      String var10000;
      switch (languageName) {
         case "english":
            var10000 = "en";
            break;
         case "custom":
            var10000 = "custom";
            break;
         case "french":
            var10000 = "fr";
            break;
         case "german":
            var10000 = "de";
            break;
         case "spanish":
            var10000 = "es";
            break;
         case "italian":
            var10000 = "it";
            break;
         case "brazilianportuguese":
            var10000 = "pt";
            break;
         case "russian":
            var10000 = "ru";
            break;
         case "chinese":
         case "chinesesimplified":
            var10000 = "zh_cn";
            break;
         case "chinesetraditional":
            var10000 = "zh_tw";
            break;
         case "japanese":
            var10000 = "ja";
            break;
         case "korean":
            var10000 = "ko";
            break;
         case "polish":
            var10000 = "pl";
            break;
         case "dutch":
            var10000 = "nl";
            break;
         case "czech":
            var10000 = "cs";
            break;
         case "hungarian":
            var10000 = "hu";
            break;
         case "romanian":
            var10000 = "ro";
            break;
         case "turkish":
            var10000 = "tr";
            break;
         case "vietnamese":
            var10000 = "vi";
            break;
         case "indonesian":
            var10000 = "id";
            break;
         default:
            var10000 = languageName;
      }

      return var10000;
   }

   private void initialize() {
      Path folder = Paths.get(MetadataHandler.PLUGIN.getDataFolder().getAbsolutePath(), "translations");
      String csvFilename = this.languageName + ".csv";
      this.translationsPath = folder.resolve(csvFilename);
      this.translationsDataPath = folder.resolve(this.languageName + "_data.csv");

      try {
         Files.createDirectories(folder);
         if (Files.exists(this.translationsPath, new LinkOption[0])) {
            this.translationData = TranslationCsvParser.parse(this.translationsPath);
            Logger.info("Loaded translations from " + csvFilename);
         } else {
            InputStream in = MetadataHandler.PLUGIN.getResource("translations/" + csvFilename);

            try {
               if (in != null) {
                  Files.copy(in, this.translationsPath, new CopyOption[0]);
                  this.translationData = TranslationCsvParser.parse(this.translationsPath);
                  Logger.info("Copied bundled translation: " + csvFilename);
               } else {
                  this.translationData = new TranslationCsvParser.TranslationData(List.of("en", this.languageCode));
                  Logger.info("Created new empty translations for: " + this.languageName);
               }
            } catch (Throwable var7) {
               if (in != null) {
                  try {
                     in.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (in != null) {
               in.close();
            }
         }

         this.translationData.addLanguage("en");
         this.translationData.addLanguage(this.languageCode);
         if (Files.exists(this.translationsDataPath, new LinkOption[0])) {
            this.translationDataSnapshot = TranslationCsvParser.parse(this.translationsDataPath);
         } else {
            this.translationDataSnapshot = new TranslationCsvParser.TranslationData(List.of("en", this.languageCode));
         }

         this.processConfigFields();
      } catch (IOException e) {
         Logger.warn("Failed to initialize translations: " + e.getMessage());
         this.translationData = new TranslationCsvParser.TranslationData(List.of("en", this.languageCode));
         this.translationDataSnapshot = new TranslationCsvParser.TranslationData(List.of("en", this.languageCode));
      }

   }

   private void processConfigFields() {
      String csvFilename = this.languageName + ".csv";

      try {
         InputStream in = MetadataHandler.PLUGIN.getResource("translations/" + csvFilename);

         label93: {
            try {
               if (in == null) {
                  break label93;
               }

               Path tempPath = Files.createTempFile("elitemobs_trans_", ".csv");
               Files.copy(in, tempPath, new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
               TranslationCsvParser.TranslationData bundledData = TranslationCsvParser.parse(tempPath);
               Files.delete(tempPath);
               boolean updated = false;

               for(String key : bundledData.getKeys()) {
                  Object bundledEnValue = bundledData.get(key, "en");
                  if (bundledEnValue != null) {
                     Object snapshotEnValue = this.translationDataSnapshot.get(key, "en");
                     Object liveEnValue = this.translationData.get(key, "en");
                     if (snapshotEnValue == null) {
                        if (liveEnValue == null) {
                           this.translationData.set(key, "en", bundledEnValue);
                           Object bundledLangValue = bundledData.get(key, this.languageCode);
                           if (bundledLangValue != null) {
                              this.translationData.set(key, this.languageCode, bundledLangValue);
                           }

                           updated = true;
                        }
                     } else if (!bundledEnValue.equals(snapshotEnValue) && snapshotEnValue.equals(liveEnValue)) {
                        this.translationData.set(key, "en", bundledEnValue);
                        Object bundledLangValue = bundledData.get(key, this.languageCode);
                        if (bundledLangValue != null) {
                           this.translationData.set(key, this.languageCode, bundledLangValue);
                        }

                        Logger.info("Auto-updated translation: " + key);
                        updated = true;
                     }

                     this.translationDataSnapshot.set(key, "en", bundledEnValue);
                     Object bundledLangValue = bundledData.get(key, this.languageCode);
                     if (bundledLangValue != null) {
                        this.translationDataSnapshot.set(key, this.languageCode, bundledLangValue);
                     }
                  }
               }

               if (updated) {
                  this.save();
                  this.saveSnapshot();
               }
            } catch (Throwable var13) {
               if (in != null) {
                  try {
                     in.close();
                  } catch (Throwable var12) {
                     var13.addSuppressed(var12);
                  }
               }

               throw var13;
            }

            if (in != null) {
               in.close();
            }

            return;
         }

         if (in != null) {
            in.close();
         }

      } catch (IOException e) {
         Logger.warn("Failed to process bundled translations: " + e.getMessage());
      }
   }

   public void add(String filename, String key, Object value) {
      if (value != null) {
         String filteredFilename = filename.replace(".yml", "");
         String realKey = filteredFilename + "." + key;
         if (value instanceof String) {
            String s = (String)value;
            String fixed = this.fixConfigColors(s);
            if (fixed.isEmpty()) {
               return;
            }

            value = fixed;
         } else if (value instanceof List) {
            List<?> list = (List)value;
            List<String> fixedList = this.fixConfigColors(list);
            if (fixedList.isEmpty()) {
               return;
            }

            value = fixedList;
         }

         if (this.translationData.get(realKey, "en") == null) {
            this.translationData.set(realKey, "en", value);
            if (!this.languageCode.equals("en") && this.translationData.get(realKey, this.languageCode) == null) {
               this.translationData.set(realKey, this.languageCode, value);
            }

            this.dirty = true;
            this.scheduleSave();
         }
      }
   }

   public Object get(String filename, String key) {
      String filteredFilename = filename.replace(".yml", "");
      String realKey = filteredFilename + "." + key;
      Object value = null;
      if (!this.languageCode.equals("en")) {
         value = this.translationData.get(realKey, this.languageCode);
      }

      if (value == null) {
         value = this.translationData.get(realKey, "en");
      }

      if (value instanceof String s) {
         return ChatColorConverter.convert(s);
      } else if (value instanceof List<?> list) {
         return ChatColorConverter.convert(list);
      } else {
         return value;
      }
   }

   private void scheduleSave() {
      if (!this.saving) {
         this.saving = true;
         Bukkit.getScheduler().scheduleSyncDelayedTask(MetadataHandler.PLUGIN, () -> {
            if (this.dirty) {
               this.save();
               this.dirty = false;
            }

            this.saving = false;
         }, 100L);
      }
   }

   private void save() {
      try {
         TranslationCsvParser.write(this.translationData, this.translationsPath);
      } catch (IOException e) {
         Logger.warn("Failed to save translations: " + e.getMessage());
      }

   }

   private void saveSnapshot() {
      try {
         TranslationCsvParser.write(this.translationDataSnapshot, this.translationsDataPath);
      } catch (IOException e) {
         Logger.warn("Failed to save translation snapshot: " + e.getMessage());
      }

   }

   private String fixConfigColors(String value) {
      return value == null ? null : value.replace("§", "&");
   }

   private List<String> fixConfigColors(List<String> values) {
      return values.stream().map(this::fixConfigColors).toList();
   }

   public String getLanguageName() {
      return this.languageName;
   }

   public String getLanguageCode() {
      return this.languageCode;
   }

   public void shutdown() {
      if (this.dirty) {
         this.save();
         this.dirty = false;
      }

   }
}
