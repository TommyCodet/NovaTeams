package com.magmaguy.elitemobs.config.wormholes.premade;

import com.magmaguy.elitemobs.config.wormholes.WormholeConfigFields;
import com.magmaguy.elitemobs.wormhole.Wormhole;

public class AGPrimisWormholeConfig extends WormholeConfigFields {
   public AGPrimisWormholeConfig() {
      super("ag_primis_wormhole", true, "em_adventurers_guild,293.5,95,290.5,90,0", "primis_adventure.yml", Wormhole.WormholeStyle.ICOSAHEDRON);
      this.setBlindPlayer(true);
      this.setLocation1Text("<g:#228B22:#32CD32>『Primis Adventure』</g> <g:#98FB98:#90EE90>Lvls 0-20</g>");
      this.setParticleColor(32768);
      this.setSizeMultiplier((double)2.0F);
      this.setCustomModel1("em_primis_portal");
   }
}
