package com.magmaguy.elitemobs.versionnotifier;

import com.magmaguy.elitemobs.MetadataHandler;
import com.magmaguy.elitemobs.config.CommandMessagesConfig;
import com.magmaguy.elitemobs.config.InitializeConfig;
import com.magmaguy.elitemobs.dungeons.EMPackage;
import com.magmaguy.elitemobs.magmacore.nightbreak.NightbreakAccount;
import com.magmaguy.elitemobs.magmacore.util.ChatColorConverter;
import com.magmaguy.elitemobs.magmacore.util.Logger;
import com.magmaguy.elitemobs.magmacore.util.SpigotMessage;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import lombok.Generated;
import net.md_5.bungee.api.chat.BaseComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class VersionChecker {
   private static final List<EMPackage> outdatedPackages = new ArrayList();
   private static final boolean SHA1Updated = false;
   private static final int MAX_RETRY_ATTEMPTS = 3;
   private static final int RETRY_DELAY_SECONDS = 60;
   private static final long REFRESH_COOLDOWN_MS = 300000L;
   private static boolean pluginIsUpToDate = true;
   private static boolean connectionFailed = false;
   private static int connectionRetryCount = 0;
   private static final long CHECK_INTERVAL_TICKS = 1728000L;
   private static volatile long lastRefreshTimestamp = 0L;

   private VersionChecker() {
   }

   public static boolean serverVersionOlderThan(int majorVersion, int minorVersion) {
      String[] splitVersion = Bukkit.getBukkitVersion().split("[.]");
      int actualMinorVersion = 0;
      int actualMajorVersion;
      if (splitVersion[0].equals("1")) {
         actualMajorVersion = Integer.parseInt(splitVersion[1].split("-")[0]);
         if (splitVersion.length > 2) {
            actualMinorVersion = Integer.parseInt(splitVersion[2].split("-")[0]);
         }
      } else {
         actualMajorVersion = Integer.parseInt(splitVersion[0].split("-")[0]);
         if (splitVersion.length > 1) {
            actualMinorVersion = Integer.parseInt(splitVersion[1].split("-")[0]);
         }
      }

      if (actualMajorVersion < majorVersion) {
         return true;
      } else if (actualMajorVersion == majorVersion) {
         return actualMinorVersion < minorVersion;
      } else {
         return false;
      }
   }

   private static void checkPluginVersion() {
      (new BukkitRunnable() {
         public void run() {
            String currentVersion = MetadataHandler.PLUGIN.getDescription().getVersion();
            boolean snapshot = false;
            if (currentVersion.contains("SNAPSHOT")) {
               snapshot = true;
               currentVersion = currentVersion.split("-")[0];
            }

            String publicVersion = "";

            try {
               publicVersion = VersionChecker.readStringFromURL("https://api.spigotmc.org/legacy/update.php?resource=40090");
               Logger.info("Latest public release is " + publicVersion);
               Logger.info("Your version is " + MetadataHandler.PLUGIN.getDescription().getVersion());
            } catch (IOException e) {
               VersionChecker.handleConnectionError("plugin version check", e);
               return;
            }

            if (Double.parseDouble(currentVersion.split("\\.")[0]) < Double.parseDouble(publicVersion.split("\\.")[0])) {
               VersionChecker.outOfDateHandler();
            } else {
               if (Double.parseDouble(currentVersion.split("\\.")[0]) == Double.parseDouble(publicVersion.split("\\.")[0])) {
                  if (Double.parseDouble(currentVersion.split("\\.")[1]) < Double.parseDouble(publicVersion.split("\\.")[1])) {
                     VersionChecker.outOfDateHandler();
                     return;
                  }

                  if (Double.parseDouble(currentVersion.split("\\.")[1]) == Double.parseDouble(publicVersion.split("\\.")[1]) && Double.parseDouble(currentVersion.split("\\.")[2]) < Double.parseDouble(publicVersion.split("\\.")[2])) {
                     VersionChecker.outOfDateHandler();
                     return;
                  }
               }

               if (!snapshot) {
                  Logger.info("You are running the latest version!");
               } else {
                  Logger.info("You are running a snapshot version! You can check for updates in the #releases channel on the EliteMobs Discord!");
               }

               VersionChecker.pluginIsUpToDate = true;
            }
         }
      }).runTaskAsynchronously(MetadataHandler.PLUGIN);
   }

   public static void shutdown() {
      outdatedPackages.clear();
      connectionRetryCount = 0;
      connectionFailed = false;
      pluginIsUpToDate = true;
      lastRefreshTimestamp = 0L;
   }

   private static String fetchFromNightbreak(String urlString) throws IOException {
      URL url = new URL(urlString);
      HttpURLConnection connection = (HttpURLConnection)url.openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", "application/json");
      connection.setConnectTimeout(10000);
      connection.setReadTimeout(10000);
      int responseCode = connection.getResponseCode();
      if (responseCode != 200) {
         throw new IOException("Nightbreak API returned status code: " + responseCode);
      } else {
         Scanner scanner = new Scanner(connection.getInputStream(), StandardCharsets.UTF_8);

         String var5;
         try {
            scanner.useDelimiter("\\A");
            var5 = scanner.hasNext() ? scanner.next() : "";
         } catch (Throwable var8) {
            try {
               scanner.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }

            throw var8;
         }

         scanner.close();
         return var5;
      }
   }

   private static Map<String, Integer> parseNightbreakDlcResponse(String json) {
      Map<String, Integer> versions = new HashMap();
      String[] categories = new String[]{"accessible", "patreonRequired", "purchaseAvailable"};

      for(String category : categories) {
         String categoryKey = "\"" + category + "\":";
         int categoryStart = json.indexOf(categoryKey);
         if (categoryStart != -1) {
            int arrayStart = json.indexOf("[", categoryStart);
            if (arrayStart != -1) {
               int arrayEnd = findMatchingBracket(json, arrayStart);
               if (arrayEnd != -1) {
                  String arrayContent = json.substring(arrayStart, arrayEnd + 1);
                  parseEntriesFromArray(arrayContent, versions);
               }
            }
         }
      }

      return versions;
   }

   private static int findMatchingBracket(String json, int openPos) {
      int depth = 0;
      boolean inString = false;

      for(int i = openPos; i < json.length(); ++i) {
         char c = json.charAt(i);
         if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
            inString = !inString;
         } else if (!inString) {
            if (c == '[') {
               ++depth;
            } else if (c == ']') {
               --depth;
               if (depth == 0) {
                  return i;
               }
            }
         }
      }

      return -1;
   }

   private static void parseEntriesFromArray(String arrayJson, Map<String, Integer> versions) {
      int objectEnd;
      for(int pos = 0; pos < arrayJson.length(); pos = objectEnd + 1) {
         int objectStart = arrayJson.indexOf("{", pos);
         if (objectStart == -1) {
            break;
         }

         objectEnd = findMatchingBrace(arrayJson, objectStart);
         if (objectEnd == -1) {
            break;
         }

         String objectJson = arrayJson.substring(objectStart, objectEnd + 1);
         String slug = extractJsonString(objectJson, "slug");
         String versionStr = extractJsonString(objectJson, "currentVersion");
         if (slug != null && versionStr != null && !versionStr.isEmpty()) {
            try {
               String numericVersion = versionStr.startsWith("v") ? versionStr.substring(1) : versionStr;
               int version = Integer.parseInt(numericVersion);
               versions.put(slug, version);
            } catch (NumberFormatException var10) {
               Logger.warn("Failed to parse version '" + versionStr + "' for slug '" + slug + "'");
            }
         } else if (slug != null && versionStr != null && versionStr.isEmpty()) {
         }
      }

   }

   private static int findMatchingBrace(String json, int openPos) {
      int depth = 0;
      boolean inString = false;

      for(int i = openPos; i < json.length(); ++i) {
         char c = json.charAt(i);
         if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
            inString = !inString;
         } else if (!inString) {
            if (c == '{') {
               ++depth;
            } else if (c == '}') {
               --depth;
               if (depth == 0) {
                  return i;
               }
            }
         }
      }

      return -1;
   }

   private static String extractJsonString(String json, String key) {
      String searchKey = "\"" + key + "\":";
      int keyIndex = json.indexOf(searchKey);
      if (keyIndex == -1) {
         return null;
      } else {
         int valueStart;
         for(valueStart = keyIndex + searchKey.length(); valueStart < json.length() && Character.isWhitespace(json.charAt(valueStart)); ++valueStart) {
         }

         if (valueStart >= json.length()) {
            return null;
         } else if (json.substring(valueStart).startsWith("null")) {
            return null;
         } else if (json.charAt(valueStart) == '"') {
            int stringEnd = json.indexOf("\"", valueStart + 1);
            return stringEnd == -1 ? null : json.substring(valueStart + 1, stringEnd);
         } else {
            return null;
         }
      }
   }

   private static void checkContentVersion() {
      if (!MetadataHandler.shutdownRequested) {
         Bukkit.getScheduler().runTaskAsynchronously(MetadataHandler.PLUGIN, () -> {
            try {
               if (MetadataHandler.shutdownRequested) {
                  return;
               }

               String jsonResponse = fetchFromNightbreak("https://nightbreak.io/api/dlc");
               if (MetadataHandler.shutdownRequested) {
                  return;
               }

               connectionFailed = false;
               connectionRetryCount = 0;
               Map<String, Integer> remoteVersions = parseNightbreakDlcResponse(jsonResponse);
               Logger.info("Parsed " + remoteVersions.size() + " content versions from Nightbreak API");
               processContentVersionData(remoteVersions);
               if (MetadataHandler.shutdownRequested) {
                  return;
               }

               prefetchAccessInfoInternal();
            } catch (IOException e) {
               if (MetadataHandler.shutdownRequested) {
                  return;
               }

               lastRefreshTimestamp = 0L;
               handleConnectionError("content version check", e);
               if (connectionRetryCount >= 3 || !(e instanceof UnknownHostException) && !(e instanceof ConnectException) && !(e instanceof SocketTimeoutException)) {
                  Logger.info("Using local data for content version checks as remote server is unavailable.");
               }
            }

         });
      }
   }

   private static void processContentVersionData(Map<String, Integer> remoteVersions) {
      List<EMPackage> newlyOutdated = new ArrayList();
      List<EMPackage> packageSnapshot = new ArrayList(EMPackage.getEmPackages().values());

      for(EMPackage emPackage : packageSnapshot) {
         if (emPackage.isInstalled()) {
            String slug = emPackage.getContentPackagesConfigFields().getNightbreakSlug();
            if (emPackage.getContentPackagesConfigFields().isDefaultDungeon() || slug != null && !slug.isEmpty()) {
               boolean containedInMetaPackage = false;

               for(EMPackage metaPackage : packageSnapshot) {
                  if (metaPackage.getContentPackagesConfigFields().getContainedPackages() != null && !metaPackage.getContentPackagesConfigFields().getContainedPackages().isEmpty() && metaPackage.getContentPackagesConfigFields().getContainedPackages().contains(emPackage.getContentPackagesConfigFields().getFilename())) {
                     containedInMetaPackage = true;
                     break;
                  }
               }

               if (!containedInMetaPackage && slug != null && !slug.isEmpty()) {
                  Integer remoteVersion = (Integer)remoteVersions.get(slug);
                  if (remoteVersion == null) {
                     String var10000 = emPackage.getContentPackagesConfigFields().getName();
                     Logger.warn("No version info found on Nightbreak for content: " + var10000 + " (slug: " + slug + ")");
                  } else {
                     int localVersion = emPackage.getContentPackagesConfigFields().getDungeonVersion();
                     if (remoteVersion > localVersion) {
                        emPackage.setOutOfDate(true);
                        if (!outdatedPackages.contains(emPackage)) {
                           outdatedPackages.add(emPackage);
                           newlyOutdated.add(emPackage);
                        }

                        Logger.warn("Content " + emPackage.getContentPackagesConfigFields().getName() + " is outdated! You should go download the updated version! Your version: " + localVersion + " / remote version: " + remoteVersion + " / Link: " + emPackage.getContentPackagesConfigFields().getDownloadLink());
                     }
                  }
               }
            }
         }
      }

      if (!newlyOutdated.isEmpty()) {
         notifyOnlineAdmins(newlyOutdated);
      }

   }

   private static void handleConnectionError(String checkType, Exception e) {
      connectionFailed = true;
      if (!(e instanceof UnknownHostException) && !(e instanceof ConnectException) && !(e instanceof SocketTimeoutException)) {
         Logger.warn("Error during " + checkType + ": " + e.getMessage());
         if (e.getCause() != null) {
            Logger.warn("Caused by: " + e.getCause().getMessage());
         }
      } else {
         ++connectionRetryCount;
         if (connectionRetryCount <= 3) {
            Logger.warn("Network error during " + checkType + ". Will retry in 60 seconds (Attempt " + connectionRetryCount + "/3)");
            Bukkit.getScheduler().runTaskLaterAsynchronously(MetadataHandler.PLUGIN, () -> checkContentVersion(), 1200L);
         } else {
            Logger.warn("Failed to connect for " + checkType + " after 3 attempts. Will continue without version checking. Error: " + e.getMessage());
         }
      }

   }

   private static String readStringFromURL(String url) throws IOException {
      Scanner scanner = new Scanner((new URL(url)).openStream(), StandardCharsets.UTF_8);

      String var2;
      try {
         scanner.useDelimiter("\\A");
         var2 = scanner.hasNext() ? scanner.next() : "";
      } catch (Throwable var5) {
         try {
            scanner.close();
         } catch (Throwable var4) {
            var5.addSuppressed(var4);
         }

         throw var5;
      }

      scanner.close();
      return var2;
   }

   private static void outOfDateHandler() {
      Logger.warn("[EliteMobs] A newer version of this plugin is available for download!");
      pluginIsUpToDate = false;
   }

   private static void notifyOnlineAdmins(List<EMPackage> newlyOutdated) {
      Bukkit.getScheduler().runTask(MetadataHandler.PLUGIN, () -> {
         for(Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission("elitemobs.versionnotification")) {
               Logger.sendSimpleMessage(player, "<g:#8B0000:#CC4400:#DAA520>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</g>");
               Logger.sendMessage(player, CommandMessagesConfig.getContentUpdatesAvailable().replace("$count", String.valueOf(newlyOutdated.size())));

               for(EMPackage emPackage : newlyOutdated) {
                  String name = emPackage.getContentPackagesConfigFields().getName();
                  player.sendMessage(CommandMessagesConfig.getContentUpdateEntry().replace("$name", name));
               }

               player.spigot().sendMessage(new BaseComponent[]{SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionUseSetupMessage()), SpigotMessage.commandHoverMessage(InitializeConfig.getEmSetupDisplay(), InitializeConfig.getEmSetupHover(), "/em setup"), SpigotMessage.simpleMessage(" &8| "), SpigotMessage.hoverLinkMessage(InitializeConfig.getContentLinkDisplay(), InitializeConfig.getContentLinkHover(), "https://nightbreak.io/plugin/elitemobs/#content")});
               if (NightbreakAccount.hasToken()) {
                  player.spigot().sendMessage(SpigotMessage.commandHoverMessage(CommandMessagesConfig.getVersionAutoUpdateMessage(), CommandMessagesConfig.getVersionAutoUpdateHover(), "/em updatecontent"));
               }

               Logger.sendSimpleMessage(player, "<g:#8B0000:#CC4400:#DAA520>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</g>");
            }
         }

      });
   }

   public static void check() {
      checkPluginVersion();
      checkContentVersion();
      NightbreakAccount.addTokenChangeListener(() -> {
         Logger.info("Nightbreak token detected — refreshing content access info.");
         invalidateRefreshCooldown();
         refreshContentAndAccess();
      });
      Bukkit.getScheduler().runTaskTimer(MetadataHandler.PLUGIN, () -> {
         Logger.info("Running scheduled 24-hour version and access check...");
         checkPluginVersion();
         checkContentVersion();
      }, 1728000L, 1728000L);
   }

   public static void refreshContentAndAccess() {
      long now = System.currentTimeMillis();
      if (now - lastRefreshTimestamp >= 300000L) {
         lastRefreshTimestamp = now;
         checkContentVersion();
      }
   }

   public static void invalidateRefreshCooldown() {
      lastRefreshTimestamp = 0L;
   }

   private static void prefetchAccessInfoInternal() {
      if (NightbreakAccount.hasToken()) {
         List<EMPackage> packageSnapshot = new ArrayList(EMPackage.getEmPackages().values());
         Map<String, NightbreakAccount.AccessInfo> slugCache = new HashMap();
         List<String> failedSlugs = new ArrayList();
         int prefetched = 0;
         boolean authFailed = NightbreakAccount.hasAuthFailure();
         if (authFailed) {
            logNightbreakTokenRejected();
         } else {
            for(EMPackage pkg : packageSnapshot) {
               if (MetadataHandler.shutdownRequested) {
                  return;
               }

               String slug = pkg.getContentPackagesConfigFields().getNightbreakSlug();
               if (slug != null && !slug.isEmpty()) {
                  NightbreakAccount.AccessInfo info;
                  if (slugCache.containsKey(slug)) {
                     info = (NightbreakAccount.AccessInfo)slugCache.get(slug);
                  } else {
                     info = NightbreakAccount.getInstance().checkAccess(slug);
                     if (NightbreakAccount.hasAuthFailure()) {
                        authFailed = true;
                        break;
                     }

                     slugCache.put(slug, info);
                     if (info == null && !failedSlugs.contains(slug)) {
                        failedSlugs.add(slug);
                     }
                  }

                  if (info != null) {
                     pkg.setCachedAccessInfo(info);
                     ++prefetched;
                  }
               }
            }

            if (prefetched > 0) {
               Logger.info("Prefetched Nightbreak access info for " + prefetched + " content packages");
            }

            if (authFailed) {
               logNightbreakTokenRejected();
            } else {
               if (!failedSlugs.isEmpty()) {
                  int var10000 = failedSlugs.size();
                  Logger.warn("Failed to prefetch access info for " + var10000 + " slugs: " + String.join(", ", failedSlugs));
               }

            }
         }
      }
   }

   private static void logNightbreakTokenRejected() {
      String status = NightbreakAccount.getLastAuthFailureStatus() > 0 ? " (HTTP " + NightbreakAccount.getLastAuthFailureStatus() + ")" : "";
      Logger.warn("Nightbreak token needs to be updated" + status + ". Get a new token at https://nightbreak.io/account/ and run /nightbreaklogin <token>, then run /em setup again.");
   }

   @Generated
   public static boolean isSHA1Updated() {
      return false;
   }

   public static class VersionCheckerEvents implements Listener {
      @EventHandler
      public void onPlayerLogin(PlayerJoinEvent event) {
         if (event.getPlayer().hasPermission("elitemobs.versionnotification")) {
            (new BukkitRunnable() {
               // $FF: synthetic field
               final PlayerJoinEvent val$event;

               {
                  this.val$event = var2;
               }

               public void run() {
                  if (this.val$event.getPlayer().isOnline()) {
                     if (VersionChecker.connectionFailed && this.val$event.getPlayer().hasPermission("elitemobs.admin")) {
                        this.val$event.getPlayer().sendMessage(CommandMessagesConfig.getVersionCheckConnectionWarning());
                     }

                     if (!VersionChecker.pluginIsUpToDate) {
                        this.val$event.getPlayer().spigot().sendMessage(new BaseComponent[]{SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionOutdatedMessage()), SpigotMessage.hoverLinkMessage(InitializeConfig.getContentLinkDisplay(), InitializeConfig.getContentLinkHover(), "https://nightbreak.io/plugin/elitemobs/")});
                     }

                     if (!VersionChecker.outdatedPackages.isEmpty()) {
                        Logger.sendSimpleMessage(this.val$event.getPlayer(), "<g:#8B0000:#CC4400:#DAA520>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</g>");
                        Logger.sendMessage(this.val$event.getPlayer(), CommandMessagesConfig.getDungeonsOutdatedMessage());

                        for(EMPackage emPackage : VersionChecker.outdatedPackages) {
                           String name = emPackage.getContentPackagesConfigFields().getName();
                           String link = emPackage.getContentPackagesConfigFields().getDownloadLink();
                           if (link != null && !link.isEmpty()) {
                              this.val$event.getPlayer().spigot().sendMessage(SpigotMessage.hoverLinkMessage(CommandMessagesConfig.getVersionOutdatedEntryPrefix() + name, ChatColorConverter.convert(CommandMessagesConfig.getVersionClickDownloadHover()), link));
                           } else {
                              Player var10000 = this.val$event.getPlayer();
                              String var10001 = CommandMessagesConfig.getVersionOutdatedEntryPrefix();
                              var10000.sendMessage(ChatColorConverter.convert(var10001 + name + CommandMessagesConfig.getVersionNoDownloadLink()));
                           }
                        }

                        this.val$event.getPlayer().spigot().sendMessage(new BaseComponent[]{SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionDownloadAtMessage()), SpigotMessage.hoverLinkMessage(InitializeConfig.getContentLinkDisplay(), InitializeConfig.getContentLinkHover(), "https://nightbreak.io/plugin/elitemobs/#content"), SpigotMessage.simpleMessage(" !")});
                        this.val$event.getPlayer().spigot().sendMessage(new BaseComponent[]{SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionUpdateEasyMessage()), SpigotMessage.hoverLinkMessage(CommandMessagesConfig.getVersionClickHereLabel(), CommandMessagesConfig.getVersionWikiHover(), "https://nightbreak.io/plugin/elitemobs/#setup"), SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionInstallInfoMessage()), SpigotMessage.hoverLinkMessage(CommandMessagesConfig.getVersionHereLabel(), CommandMessagesConfig.getVersionDiscordHover(), "https://discord.gg/eSxvPbWYy4"), SpigotMessage.simpleMessage(CommandMessagesConfig.getVersionSupportRoomMessage())});
                        if (NightbreakAccount.hasToken()) {
                           this.val$event.getPlayer().spigot().sendMessage(SpigotMessage.commandHoverMessage(CommandMessagesConfig.getVersionAutoUpdateMessage(), CommandMessagesConfig.getVersionAutoUpdateHover(), "/em updatecontent"));
                        }

                        Logger.sendSimpleMessage(this.val$event.getPlayer(), "<g:#8B0000:#CC4400:#DAA520>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</g>");
                     }

                  }
               }
            }).runTaskLater(MetadataHandler.PLUGIN, 60L);
         }
      }
   }
}
